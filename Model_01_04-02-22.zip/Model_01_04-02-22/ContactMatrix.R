#install.packages('socialmixr')
library('socialmixr')
data(polymod)
#The Data are fully described in 
#Mossong J, Hens N, Jit M, Beutels P, Auranen K, Mikolajczyk R, et al. (2008) 
#Social Contacts and Mixing Patterns Relevant to the Spread of Infectious Diseases.PLoS Med 5(3): e74.

population_all_regions <- read.csv('C:/Users/andre/OneDrive/Desktop/Tesi/Data/Regions_population/regionspopulation.csv')
#population_all_regions <- read.csv('https://raw.githubusercontent.com/andbizz/thesis/main/regionspopulation.csv')

#--- Selection of population in Lombardia

population_lombardia <- population_all_regions[which(population_all_regions$region == 'lombardia'),]

#--- Setting of the population in each age group

population_lombardia_0_9_value  <- population_lombardia[which(population_lombardia$group == '0-9'   ),3]
population_lombardia_10_19_value <- population_lombardia[which(population_lombardia$group == '10-19' ),3]
population_lombardia_20_29_value <- population_lombardia[which(population_lombardia$group == '20-29' ),3]
population_lombardia_30_39_value <- population_lombardia[which(population_lombardia$group == '30-39' ),3]
population_lombardia_40_49_value <- population_lombardia[which(population_lombardia$group == '40-49' ),3]
population_lombardia_50_59_value <- population_lombardia[which(population_lombardia$group == '50-59' ),3]
population_lombardia_60_69_value <- population_lombardia[which(population_lombardia$group == '60-69' ),3]
population_lombardia_70_79_value <- population_lombardia[which(population_lombardia$group == '70-79' ),3]
population_lombardia_80_89_value <- population_lombardia[which(population_lombardia$group == '80-89' ),3]
population_lombardia_over90_value <- population_lombardia[which(population_lombardia$group =='over90'),3]


#--- Creation of the data-set to comparing with the simulations in Rstan

#--- Demographic Population

N_0_9_data   <- as.integer(as.numeric(population_lombardia_0_9_value))
N_10_19_data <- as.integer(as.numeric(population_lombardia_10_19_value))
N_20_29_data <- as.integer(as.numeric(population_lombardia_20_29_value))
N_30_39_data <- as.integer(as.numeric(population_lombardia_30_39_value))
N_40_49_data <- as.integer(as.numeric(population_lombardia_40_49_value))
N_50_59_data <- as.integer(as.numeric(population_lombardia_50_59_value))
N_60_69_data <- as.integer(as.numeric(population_lombardia_60_69_value))
N_70_79_data <- as.integer(as.numeric(population_lombardia_70_79_value))
N_80_89_data <- as.integer(as.numeric(population_lombardia_80_89_value))
N_over90_data <-as.integer(as.numeric(population_lombardia_over90_value))



#--- Setting the data in an unique vector
# this could be useful for the setting of the likelihood in vectorized form (faster)

#--- Population

N_data <- c(N_0_9_data+N_10_19_data,N_20_29_data+N_30_39_data,N_40_49_data+N_50_59_data,
            N_60_69_data+N_70_79_data,N_80_89_data+N_over90_data)



C <- contact_matrix(polymod, countries = "Italy", age.limits = c(0, 20, 40, 60, 80, 90, 100))

Contact_Matrix <- C$matrix

Contact_Matrix <- data.frame(Contact_Matrix)

Groups <- c('0-19','20-39','40-59','60-79','over80')
colnames(Contact_Matrix) <- Groups
rownames(Contact_Matrix) <- Groups

write.csv(Contact_Matrix, file = "contact_matrix.csv",row.names = FALSE)


contacts <- contact_matrix(polymod,
                           countries = "Italy",
                           age.limits = c(0, 20, 40, 60, 80, 90, 100),
                           symmetric = TRUE,
                           survey.pop = data.frame(
                                                   lower.age.limit = c(0,20, 40, 60, 80),
                                                   population = N_data))




