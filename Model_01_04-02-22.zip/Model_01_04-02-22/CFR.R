data_lombardia <- read.csv('C:/Users/andre/OneDrive/Desktop/Tesi/Dataset/data_lombardia.csv')
data_lombardia <- data.frame(data_lombardia)

start <- "2020-03-01"
end <- "2020-05-31"

data_lombardia_positive <- data_lombardia[which(data_lombardia$type == "positive" ),]

data_lombardia_positive_0_9_values   <- data_lombardia_positive[which(data_lombardia_positive$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_positive_0_9_values[,1])
index_end <- tail(which(data_lombardia_positive_0_9_values[,1] == end), n = 1)

data_lombardia_positive_0_9_values   <- data_lombardia_positive[which(data_lombardia_positive$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_positive_10_19_values <- data_lombardia_positive[which(data_lombardia_positive$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_positive_20_29_values <- data_lombardia_positive[which(data_lombardia_positive$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_positive_30_39_values <- data_lombardia_positive[which(data_lombardia_positive$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_positive_40_49_values <- data_lombardia_positive[which(data_lombardia_positive$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_positive_50_59_values <- data_lombardia_positive[which(data_lombardia_positive$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_positive_60_69_values <- data_lombardia_positive[which(data_lombardia_positive$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_positive_70_79_values <- data_lombardia_positive[which(data_lombardia_positive$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_positive_80_89_values <- data_lombardia_positive[which(data_lombardia_positive$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_positive_over90_values <- data_lombardia_positive[which(data_lombardia_positive$group == "over90"),][index_start:index_end,2]

POS_0_9_data   <- sum(as.integer(data_lombardia_positive_0_9_values)) 
POS_10_19_data <- sum(as.integer(data_lombardia_positive_10_19_values)) 
POS_20_29_data <- sum(as.integer(data_lombardia_positive_20_29_values)) 
POS_30_39_data <- sum(as.integer(data_lombardia_positive_30_39_values)) 
POS_40_49_data <- sum(as.integer(data_lombardia_positive_40_49_values)) 
POS_50_59_data <- sum(as.integer(data_lombardia_positive_50_59_values)) 
POS_60_69_data <- sum(as.integer(data_lombardia_positive_60_69_values)) 
POS_70_79_data <- sum(as.integer(data_lombardia_positive_70_79_values)) 
POS_80_89_data <- sum(as.integer(data_lombardia_positive_80_89_values)) 
POS_over90_data <-sum(as.integer(data_lombardia_positive_over90_values))


data_lombardia_deaths <- data_lombardia[which(data_lombardia$type == "deaths" ),]

data_lombardia_deaths_0_9_values   <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_deaths_0_9_values[,1])
index_end <- tail(which(data_lombardia_deaths_0_9_values[,1] == end), n = 1)

data_lombardia_deaths_0_9_values   <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_deaths_10_19_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_deaths_20_29_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_deaths_30_39_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_deaths_40_49_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_deaths_50_59_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_deaths_60_69_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_deaths_70_79_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_deaths_80_89_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_deaths_over90_values <- data_lombardia_deaths[which(data_lombardia_deaths$group == "over90"),][index_start:index_end,2]

D_0_9_data   <- sum(as.integer(data_lombardia_deaths_0_9_values)) 
D_10_19_data <- sum(as.integer(data_lombardia_deaths_10_19_values)) 
D_20_29_data <- sum(as.integer(data_lombardia_deaths_20_29_values)) 
D_30_39_data <- sum(as.integer(data_lombardia_deaths_30_39_values)) 
D_40_49_data <- sum(as.integer(data_lombardia_deaths_40_49_values)) 
D_50_59_data <- sum(as.integer(data_lombardia_deaths_50_59_values)) 
D_60_69_data <- sum(as.integer(data_lombardia_deaths_60_69_values)) 
D_70_79_data <- sum(as.integer(data_lombardia_deaths_70_79_values)) 
D_80_89_data <- sum(as.integer(data_lombardia_deaths_80_89_values)) 
D_over90_data <-sum(as.integer(data_lombardia_deaths_over90_values)) 

CFR_0_19 <- ( D_0_9_data + D_10_19_data ) / ( POS_0_9_data + POS_10_19_data )
CFR_20_39 <- ( D_20_29_data + D_30_39_data ) / ( POS_20_29_data + POS_30_39_data )
CFR_40_59 <- ( D_40_49_data + D_50_59_data ) / ( POS_40_49_data + POS_50_59_data )
CFR_60_79 <- ( D_60_69_data + D_70_79_data ) / ( POS_60_69_data + POS_70_79_data )
CFR_over80 <- ( D_80_89_data + D_over90_data ) / ( POS_80_89_data + POS_over90_data )

CFR_vec <- c(CFR_0_19, CFR_20_39, CFR_40_59, CFR_60_79, CFR_over80)

saveRDS(CFR_vec, "cfr.rds")

