library(truncnorm)

##  Dati ----- 

data_lombardia <- read.csv('C:/Users/andre/OneDrive/Desktop/Tesi/Dataset/data_lombardia.csv')
data_lombardia <- data.frame(data_lombardia)

start <- "2020-03-01"
end <- "2020-05-31"

data_lombardia_symptomatic <- data_lombardia[which(data_lombardia$type == "symptomatic" ),]

data_lombardia_symptomatic_0_9_values   <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_symptomatic_0_9_values[,1])
index_end <- tail(which(data_lombardia_symptomatic_0_9_values[,1] == end), n = 1)

data_lombardia_symptomatic_0_9_values   <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_symptomatic_10_19_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_symptomatic_20_29_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_symptomatic_30_39_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_symptomatic_40_49_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_symptomatic_50_59_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_symptomatic_60_69_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_symptomatic_70_79_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_symptomatic_80_89_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_symptomatic_over90_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group == "over90"),][index_start:index_end,2]

IS_0_9_data   <- as.integer(data_lombardia_symptomatic_0_9_values) 
IS_10_19_data <- as.integer(data_lombardia_symptomatic_10_19_values) 
IS_20_29_data <- as.integer(data_lombardia_symptomatic_20_29_values) 
IS_30_39_data <- as.integer(data_lombardia_symptomatic_30_39_values) 
IS_40_49_data <- as.integer(data_lombardia_symptomatic_40_49_values) 
IS_50_59_data <- as.integer(data_lombardia_symptomatic_50_59_values) 
IS_60_69_data <- as.integer(data_lombardia_symptomatic_60_69_values) 
IS_70_79_data <- as.integer(data_lombardia_symptomatic_70_79_values) 
IS_80_89_data <- as.integer(data_lombardia_symptomatic_80_89_values) 
IS_over90_data <-as.integer(data_lombardia_symptomatic_over90_values)

data_lombardia_recovered <- data_lombardia[which(data_lombardia$type == "recovered" ),]

data_lombardia_recovered_0_9_values   <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_recovered_0_9_values[,1])
index_end <- tail(which(data_lombardia_recovered_0_9_values[,1] == end), n = 1)

data_lombardia_recovered_0_9_values   <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_recovered_10_19_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_recovered_20_29_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_recovered_30_39_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_recovered_40_49_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_recovered_50_59_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_recovered_60_69_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_recovered_70_79_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_recovered_80_89_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_recovered_over90_values <- data_lombardia_recovered[which(data_lombardia_recovered$group == "over90"),][index_start:index_end,2]

H_0_9_data   <- as.integer(data_lombardia_recovered_0_9_values) 
H_10_19_data <- as.integer(data_lombardia_recovered_10_19_values) 
H_20_29_data <- as.integer(data_lombardia_recovered_20_29_values) 
H_30_39_data <- as.integer(data_lombardia_recovered_30_39_values) 
H_40_49_data <- as.integer(data_lombardia_recovered_40_49_values) 
H_50_59_data <- as.integer(data_lombardia_recovered_50_59_values) 
H_60_69_data <- as.integer(data_lombardia_recovered_60_69_values) 
H_70_79_data <- as.integer(data_lombardia_recovered_70_79_values) 
H_80_89_data <- as.integer(data_lombardia_recovered_80_89_values) 
H_over90_data <-as.integer(data_lombardia_recovered_over90_values) 

data_lombardia_intcare <- data_lombardia[which(data_lombardia$type == "intensive_care" ),]

data_lombardia_intcare_0_9_values   <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_intcare_0_9_values[,1])
index_end <- tail(which(data_lombardia_intcare_0_9_values[,1] == end), n = 1)

data_lombardia_intcare_0_9_values   <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_intcare_10_19_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_intcare_20_29_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_intcare_30_39_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_intcare_40_49_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_intcare_50_59_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_intcare_60_69_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_intcare_70_79_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_intcare_80_89_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_intcare_over90_values <- data_lombardia_intcare[which(data_lombardia_intcare$group == "over90"),][index_start:index_end,2]

IC_0_9_data   <- as.integer(data_lombardia_intcare_0_9_values) 
IC_10_19_data <- as.integer(data_lombardia_intcare_10_19_values) 
IC_20_29_data <- as.integer(data_lombardia_intcare_20_29_values) 
IC_30_39_data <- as.integer(data_lombardia_intcare_30_39_values) 
IC_40_49_data <- as.integer(data_lombardia_intcare_40_49_values) 
IC_50_59_data <- as.integer(data_lombardia_intcare_50_59_values) 
IC_60_69_data <- as.integer(data_lombardia_intcare_60_69_values) 
IC_70_79_data <- as.integer(data_lombardia_intcare_70_79_values) 
IC_80_89_data <- as.integer(data_lombardia_intcare_80_89_values) 
IC_over90_data <-as.integer(data_lombardia_intcare_over90_values) 

data_lombardia_deaths <- data_lombardia[which(data_lombardia$type == "deaths" ),]

data_lombardia_deaths_0_9_values   <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_deaths_0_9_values[,1])
index_end <- tail(which(data_lombardia_deaths_0_9_values[,1] == end), n = 1)

data_lombardia_deaths_0_9_values   <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_deaths_10_19_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_deaths_20_29_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_deaths_30_39_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_deaths_40_49_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_deaths_50_59_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_deaths_60_69_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_deaths_70_79_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_deaths_80_89_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_deaths_over90_values <- data_lombardia_deaths[which(data_lombardia_deaths$group == "over90"),][index_start:index_end,2]

D_0_9_data   <- as.integer(data_lombardia_deaths_0_9_values) 
D_10_19_data <- as.integer(data_lombardia_deaths_10_19_values) 
D_20_29_data <- as.integer(data_lombardia_deaths_20_29_values) 
D_30_39_data <- as.integer(data_lombardia_deaths_30_39_values) 
D_40_49_data <- as.integer(data_lombardia_deaths_40_49_values) 
D_50_59_data <- as.integer(data_lombardia_deaths_50_59_values) 
D_60_69_data <- as.integer(data_lombardia_deaths_60_69_values) 
D_70_79_data <- as.integer(data_lombardia_deaths_70_79_values) 
D_80_89_data <- as.integer(data_lombardia_deaths_80_89_values) 
D_over90_data <-as.integer(data_lombardia_deaths_over90_values) 

population_all_regions <- read.csv('C:/Users/andre/OneDrive/Desktop/Tesi/Dataset/regionspopulation.csv')
population_lombardia <- population_all_regions[which(population_all_regions$region == 'lombardia'),]

population_lombardia_0_9_value  <- population_lombardia[which(population_lombardia$group == '0-9'   ),3]
population_lombardia_10_19_value <- population_lombardia[which(population_lombardia$group == '10-19' ),3]
population_lombardia_20_29_value <- population_lombardia[which(population_lombardia$group == '20-29' ),3]
population_lombardia_30_39_value <- population_lombardia[which(population_lombardia$group == '30-39' ),3]
population_lombardia_40_49_value <- population_lombardia[which(population_lombardia$group == '40-49' ),3]
population_lombardia_50_59_value <- population_lombardia[which(population_lombardia$group == '50-59' ),3]
population_lombardia_60_69_value <- population_lombardia[which(population_lombardia$group == '60-69' ),3]
population_lombardia_70_79_value <- population_lombardia[which(population_lombardia$group == '70-79' ),3]
population_lombardia_80_89_value <- population_lombardia[which(population_lombardia$group == '80-89' ),3]
population_lombardia_over90_value <- population_lombardia[which(population_lombardia$group =='over90'),3]

N_0_9_data   <- as.integer(as.numeric(population_lombardia_0_9_value))
N_10_19_data <- as.integer(as.numeric(population_lombardia_10_19_value))
N_20_29_data <- as.integer(as.numeric(population_lombardia_20_29_value))
N_30_39_data <- as.integer(as.numeric(population_lombardia_30_39_value))
N_40_49_data <- as.integer(as.numeric(population_lombardia_40_49_value))
N_50_59_data <- as.integer(as.numeric(population_lombardia_50_59_value))
N_60_69_data <- as.integer(as.numeric(population_lombardia_60_69_value))
N_70_79_data <- as.integer(as.numeric(population_lombardia_70_79_value))
N_80_89_data <- as.integer(as.numeric(population_lombardia_80_89_value))
N_over90_data <-as.integer(as.numeric(population_lombardia_over90_value))

N_data <- c(N_0_9_data+N_10_19_data,N_20_29_data+N_30_39_data,
            N_40_49_data+N_50_59_data,N_60_69_data+N_70_79_data,
            N_80_89_data+N_over90_data)

n_fitting <- index_end - index_start + 1

n_seed <- 21



# un dato ogni x

x <- 1
n_simulation <- n_seed + n_fitting + 3
s <- seq(1,n_fitting,x)

n_fitting <- length(s)

IS_0_19_data <-  IS_0_9_data[s] +  IS_10_19_data[s]
IS_20_39_data <-  IS_20_29_data[s] +  IS_30_39_data[s]
IS_40_59_data <-  IS_40_49_data[s] +  IS_50_59_data[s]
IS_60_79_data <-  IS_60_69_data[s] +  IS_70_79_data[s]
IS_over80_data <-  IS_80_89_data[s] +  IS_over90_data[s]
H_0_19_data <- H_0_9_data[s] + H_10_19_data[s]
H_20_39_data <- H_20_29_data[s] + H_30_39_data[s]
H_40_59_data <- H_40_49_data[s] + H_50_59_data[s]
H_60_79_data <- H_60_69_data[s] + H_70_79_data[s]
H_over80_data <- H_80_89_data[s] + H_over90_data[s]
IC_0_19_data <- IC_0_9_data[s] + IC_10_19_data[s]
IC_20_39_data <- IC_20_29_data[s] + IC_30_39_data[s]
IC_40_59_data <- IC_40_49_data[s] + IC_50_59_data[s]
IC_60_79_data <- IC_60_69_data[s] + IC_70_79_data[s]
IC_over80_data <- IC_80_89_data[s] + IC_over90_data[s]
D_0_19_data <- D_0_9_data[s] + D_10_19_data[s]
D_20_39_data <- D_20_29_data[s] + D_30_39_data[s]
D_40_59_data <- D_40_49_data[s] + D_50_59_data[s]
D_60_79_data <- D_60_69_data[s] + D_70_79_data[s]
D_over80_data <- D_80_89_data[s] + D_over90_data[s]

contact_matrix <- read.csv('C:/Users/andre/OneDrive/Desktop/Tesi/Dataset/contact_matrix_2.csv')

rownames(contact_matrix) <- c('0-19','20-39','40-59','60-79','over80')
colnames(contact_matrix) <- c('0-19','20-39','40-59','60-79','over80')
C_matrix <- matrix(rep(0,25),nrow = 5, ncol = 5)
K <- matrix(rep(0,25),nrow = 5, ncol = 5)
for (i in 1:5){
  for (j in 1:5) {
    C_matrix[i,j] <- (N_data[i] * contact_matrix[i,j] + N_data[j] * contact_matrix[j,i] )/(2*N_data[i])
    K[i,j] <- C_matrix[i,j]*N_data[i]/N_data[j]
  }
}

C_matrix <- as.matrix(C_matrix)
ee <- eigen(K)
sr <- max(ee$values)
 

time_sequence <- seq(0, n_simulation, by = x)
initial_time = 0 
time_sequence <- time_sequence[-1]


##  Parametri Fissati ----
phi  <- readRDS("cfr.rds")

r_P <- 0.8537
r_S <- 1
r_A <- 0.5854
sigma <- 1/3.69
eta <- 1/(5.2-3.69)
xi_0_19 <- 18.09/100
xi_20_39 <- 22.41/100 
xi_40_59 <- 30.54/100 
xi_60_79 <- 35.46/100
xi_over80 <- 64.56/100
phi_0_19 <-   phi [1]
phi_20_39 <-  phi [2]
phi_40_59 <-  phi [3]
phi_60_79 <-  phi [4]
phi_over80 <- phi [5]
gamma_H_0_19 <- 1/3 
gamma_H_20_39 <- 1/6.8 
gamma_H_40_59 <- 1/6.8 
gamma_H_60_79 <- 1/5.8 
gamma_H_over80 <- 1/3.9
gamma_R <- 1/2.4
delta_IC <- 1/3 
delta_D <- 1/6
delta_R <- 1/11
epsilon <- 0.05009  
mu <- 0.2
alpha_0_19 <- 0
alpha_over80 <- 0
psi_0_19 <- 0
psi_20_39 <- 0

pars <- c(  r_P, r_S, r_A,sigma,eta,
            xi_0_19, xi_20_39, xi_40_59, xi_60_79, xi_over80,
            phi_0_19, phi_20_39, phi_40_59, phi_60_79, phi_over80,
            gamma_H_0_19, gamma_H_20_39, gamma_H_40_59, gamma_H_60_79, gamma_H_over80,
            gamma_R,
            delta_IC,delta_D, delta_R, epsilon, mu,
            alpha_0_19, alpha_over80, psi_0_19, psi_20_39
            )

data_model <- list(n_sim = n_simulation,
                   n_fit = n_fitting,
                   initial_time = initial_time,
                   time_sequence = time_sequence,
                   n_seed = n_seed,
                   pars = pars,
                   N_data = N_data,
                   IS_0_19_data =  IS_0_19_data,
                   IS_20_39_data =  IS_20_29_data,
                   IS_40_59_data =  IS_40_59_data,
                   IS_60_79_data =  IS_60_79_data,
                   IS_over80_data =  IS_over80_data,
                   H_0_19_data = H_0_19_data,
                   H_20_39_data = H_20_29_data,
                   H_40_59_data = H_40_59_data,
                   H_60_79_data = H_60_79_data,
                   H_over80_data = H_over80_data,
                   IC_0_19_data = IC_0_19_data,
                   IC_20_39_data = IC_20_29_data,
                   IC_40_59_data = IC_40_59_data,
                   IC_60_79_data = IC_60_79_data,
                   IC_over80_data = IC_over80_data,
                   D_0_19_data = D_0_19_data,
                   D_20_39_data = D_20_29_data,
                   D_40_59_data = D_40_59_data,
                   D_60_79_data = D_60_79_data,
                   D_over80_data = D_over80_data,
                   contact_matrix = C_matrix,
                   rel_tol = 1e-4,
                   abs_tol = 1e-4,
                   max_num_steps = 5000
                   )
## Dati Iniziali ----

init = function(){

  list( beta_0_19 =     runif(1, a=0.025,   b=0.035),
        beta_20_39 =    runif(1, a=0.04,    b=0.045),
        beta_40_59 =    runif(1, a=0.045,   b=0.05),
        beta_60_79 =    runif(1, a=0.065,   b=0.075),
        beta_over80 =   runif(1, a=0.06,    b=0.085),
        s  =            runif(1, a=0.0475,  b=0.0525),
        l  =            runif(1, a=0.57,    b=0.63),
        nu  =           runif(1, a=0.57,    b=0.63),
        omega_0_19  =   runif(1, a=0.0285,  b=0.0315),
        omega_20_39  =  runif(1, a=0.26125, b=0.28875),
        omega_40_59  =  runif(1, a=0.4275,  b=0.4725),
        omega_60_79  =  runif(1, a=0.57,    b=0.63),
        omega_over80  = runif(1, a=0.5,     b=0.55),
        gamma_D_0_19  = runif(1, a=0.01,    b=0.2),
        gamma_D_20_39  =runif(1, a=0.01,    b=0.2),
        gamma_D_40_59  =runif(1, a=0.01,    b=0.2),
        gamma_D_60_79  =runif(1, a=0.01,    b=0.2),
        gamma_D_over80 =runif(1, a=0.01,    b=0.2),
        alpha_20_39  =  runif(1, a=0.02565, b=0.02835),
        alpha_40_59  =  runif(1, a=0.05035, b=0.05565),
        alpha_60_79  =  runif(1, a=0.05035, b=0.05565),
        psi_40_59  =    runif(1, a=0.005,   b=0.02),
        psi_60_79  =    runif(1, a=0.075,   b=0.125),
        psi_over80  =   runif(1, a=0.4,     b=0.4725),
        rho_0_19  =     runif(1, a=0.075,   b=0.125),
        rho_20_39  =    runif(1, a=0.275,   b=0.325),
        rho_40_59  =    runif(1, a=0.475,   b=0.515),
        rho_60_79  =    runif(1, a=0.55,    b=0.6),
        rho_over80  =   runif(1, a=0.725,   b=0.775),
        iA0  =          runif(1, a=2850,    b=3150)
  )}

saveRDS(init,"init.rds")
saveRDS(data_model,"data_model.rds")
