# negative binomial simulation

mean <- 100

overdispersion <- 2.50000

Sample <-rnbinom(n=100000, size=overdispersion, mu=mean)

dens <- density(Sample, adjust = 2)
 
med <- median(Sample)
hist(Sample)
plot(dens)

print(med)