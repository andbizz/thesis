library(deSolve)
library(rstan)
library(gridExtra)
library(truncnorm)
#library(shinystan)
rstan_options (auto_write = TRUE)
options (mc.cores = parallel::detectCores ())

init <- readRDS('init.rds')

data_model <- readRDS('data_model.rds')

control <- list(adapt_engaged = TRUE,
                adapt_gamma = 0.05,
                adapt_delta = 0.8,
                adapt_kappa = 0.75,
                adapt_t0 = 10,
                adapt_init_buffer = 75,
                adapt_term_buffer = 50,
                adapt_window = 25
                )

model <- stan_model("Model.stan")

fit <- sampling(model, 
                init = init,
                data = data_model,
                iter = 500,
                chains = 4, 
                save_warmup = TRUE,
                refresh = max(1, 1))
               
                
dir_output  <- file.path("Simulation_01")
dir.create(dir_output,  recursive = TRUE, showWarnings = FALSE)
stringa <- "C:/Users/andre/OneDrive/Desktop/Tesi/Simulazioni/Vari_modelli/Modello_1/Model_01_04-02-22/Simulation_01/fit.rds"

saveRDS(fit,stringa)

#fit <- readRDS("C:/Users/andre/OneDrive/Desktop/Tesi/Simulazioni/Prima_ondata/Lombardia/Modello Finale/Completo/Simulation_5gruppi_new_22/fit.rds")
fit <- readRDS("fit.rds")
pars=c('beta',
       's', 'l','nu', 
       'omega_0_19','omega_20_39','omega_40_59','omega_60_79','omega_over80',
       'gamma_D_0_19','gamma_D_20_39','gamma_D_40_59','gamma_D_60_79','gamma_D_over80',
       'alpha_20_39','alpha_40_59','alpha_60_79',
       'psi_40_59','psi_60_79','psi_over80',
       'rho_0_19','rho_20_39','rho_40_59','rho_60_79','rho_over80',
       'iA0')

print(fit, pars = pars)

tab <- cbind(pars,data.frame(summary(fit))[1:length(pars),])
#fit <- readRDS("fit.rds")
stan_dens(fit, pars = pars, separate_chains = TRUE)

params <- extract(fit)

beta <- params$beta
s <- params$s
l <- params$l
nu <- params$nu
omega_0_19 <- params$omega_0_19
omega_20_39 <- params$omega_20_39
omega_40_59 <- params$omega_40_59
omega_60_79 <- params$omega_60_79
omega_over80 <- params$omega_over80
gamma_D_0_19 <- params$gamma_D_0_19
gamma_D_20_39 <- params$gamma_D_20_39
gamma_D_40_59 <- params$gamma_D_40_59
gamma_D_60_79 <- params$gamma_D_60_79
gamma_D_over80 <- params$gamma_D_over80

alpha_20_39 <- params$alpha_20_39
alpha_40_59 <- params$alpha_40_59
alpha_60_79 <- params$alpha_60_79

psi_40_59 <- params$psi_40_59
psi_60_79 <- params$psi_60_79
psi_over80 <- params$psi_over80
rho_0_19 <- params$rho_0_19
rho_20_39 <- params$rho_20_39
rho_40_59 <- params$rho_40_59
rho_60_79 <- params$rho_60_79
rho_over80 <- params$rho_over80
iA0 <- params$iA0


parameters <- cbind( beta, 
                     s ,  l , nu,
                     omega_0_19 , omega_20_39 , omega_40_59 , omega_60_79 , omega_over80 ,
                     gamma_D_0_19 , gamma_D_20_39 , gamma_D_40_59 , gamma_D_60_79 , gamma_D_over80 ,
                      alpha_20_39 , alpha_40_59 , alpha_60_79 ,
                      psi_40_59 , psi_60_79 , psi_over80 ,
                     rho_0_19 , rho_20_39 , rho_40_59 , rho_60_79 , rho_over80 ,
                     iA0 
                     )

#write.csv(parameters, file = "C:/Users/andre/OneDrive/Desktop/Tesi/Simulazioni/Vari_modelli/Modello_1/Model_01_04-02-22/Simulation_01/parameters_samples.csv",row.names = FALSE)
#write.csv(tab, file = "C:/Users/andre/OneDrive/Desktop/Tesi/Simulazioni/Vari_modelli/Modello_1/Model_01_04-02-22/Simulation_01/parameters_statistics.csv",row.names = FALSE)

#launch_shinystan(fit)



# Graphics ----

n_fitting <- data_model$n_fit

n_seed <- data_model$n_seed

time_sequence_pred <- (1:n_fitting)+n_seed

IS_dataset <- data.frame(time_sequence_pred,
                         data_model$IS_0_19_data ,data_model$IS_20_39_data,
                         data_model$IS_40_59_data,data_model$IS_60_79_data,
                         data_model$IS_over80_data)

H_dataset <- data.frame(time_sequence_pred,
                        data_model$H_0_19_data, data_model$H_20_39_data,
                        data_model$H_40_59_data,data_model$H_60_79_data,
                        data_model$H_over80_data)

IC_dataset <- data.frame(time_sequence_pred,
                         data_model$IC_0_19_data, data_model$IC_20_39_data,
                         data_model$IC_40_59_data,data_model$IC_60_79_data,
                         data_model$IC_over80_data)

D_dataset <- data.frame(time_sequence_pred,
                        data_model$D_0_19_data,data_model$D_20_39_data,
                        data_model$D_40_59_data,data_model$D_60_79_data,
                        data_model$D_over80_data)

app <- c('time_sequence','Group1','Group2','Group3','Group4','Group5')

colnames(IS_dataset) <- app
colnames(H_dataset) <- app
colnames(IC_dataset) <- app
colnames(D_dataset) <- app


pred_IS_0_19 <- cbind(as.data.frame(summary(fit, pars="pred_IS_0_19",
                                                probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IS_0_19) <- make.names(colnames(pred_IS_0_19)) 

pred_IS_20_39 <- cbind(as.data.frame(summary(fit, pars="pred_IS_20_39",
                                                 probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IS_20_39) <- make.names(colnames(pred_IS_20_39))

pred_IS_40_59 <- cbind(as.data.frame(summary(fit, pars="pred_IS_40_59",
                                                 probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IS_40_59) <- make.names(colnames(pred_IS_40_59))

pred_IS_60_79 <- cbind(as.data.frame(summary(fit, pars="pred_IS_60_79",
                                                 probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IS_60_79) <- make.names(colnames(pred_IS_60_79))

pred_IS_over80 <- cbind(as.data.frame(summary(fit, pars="pred_IS_over80",
                                                  probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IS_over80) <- make.names(colnames(pred_IS_over80)) 


pred_H_0_19 <- cbind(as.data.frame(summary(fit, pars="pred_H_0_19",
                                           probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_H_0_19) <- make.names(colnames(pred_H_0_19)) 

pred_H_20_39 <- cbind(as.data.frame(summary(fit, pars="pred_H_20_39",
                                            probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_H_20_39) <- make.names(colnames(pred_H_20_39))

pred_H_40_59 <- cbind(as.data.frame(summary(fit, pars="pred_H_40_59",
                                            probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_H_40_59) <- make.names(colnames(pred_H_40_59))

pred_H_60_79 <- cbind(as.data.frame(summary(fit, pars="pred_H_60_79",
                                            probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_H_60_79) <- make.names(colnames(pred_H_60_79))

pred_H_over80 <- cbind(as.data.frame(summary(fit, pars="pred_H_over80",
                                             probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_H_over80) <- make.names(colnames(pred_H_over80))

pred_IC_0_19 <- cbind(as.data.frame(summary(fit, pars="pred_IC_0_19",
                                            probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IC_0_19) <- make.names(colnames(pred_IC_0_19)) 

pred_IC_20_39 <- cbind(as.data.frame(summary(fit, pars="pred_IC_20_39",
                                             probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IC_20_39) <- make.names(colnames(pred_IC_20_39))

pred_IC_40_59 <- cbind(as.data.frame(summary(fit, pars="pred_IC_40_59",
                                             probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IC_40_59) <- make.names(colnames(pred_IC_40_59))

pred_IC_60_79 <- cbind(as.data.frame(summary(fit, pars="pred_IC_60_79",
                                             probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IC_60_79) <- make.names(colnames(pred_IC_60_79))

pred_IC_over80 <- cbind(as.data.frame(summary(fit, pars="pred_IC_over80",
                                              probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_IC_over80) <- make.names(colnames(pred_IC_over80))


pred_D_0_19 <- cbind(as.data.frame(summary(fit, pars="pred_D_0_19",
                                           probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_D_0_19) <- make.names(colnames(pred_D_0_19)) 

pred_D_20_39 <- cbind(as.data.frame(summary(fit, pars="pred_D_20_39",
                                            probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_D_20_39) <- make.names(colnames(pred_D_20_39))

pred_D_40_59 <- cbind(as.data.frame(summary(fit, pars="pred_D_40_59",
                                            probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_D_40_59) <- make.names(colnames(pred_D_40_59))

pred_D_60_79 <- cbind(as.data.frame(summary(fit, pars="pred_D_60_79",
                                            probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_D_60_79) <- make.names(colnames(pred_D_60_79))

pred_D_over80 <- cbind(as.data.frame(summary(fit, pars="pred_D_over80",
                                             probs=c(0.05, 0.50, 0.95))$summary), 1:n_fitting)
colnames(pred_D_over80) <- make.names(colnames(pred_D_over80))


p_IS = ggplot() + 
  geom_line(data = pred_IS_0_19, aes(x = time_sequence_pred, y = mean), color = "cornflowerblue") +
  geom_ribbon(data = pred_IS_0_19,aes(ymin = X5., ymax = X95.,
                                      y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "cornflowerblue", alpha = 0.35) +
  geom_point(data = IS_dataset, aes(x = time_sequence_pred, y = Group1), color = "cornflowerblue") +
  
  geom_line(data = pred_IS_20_39, aes(x = time_sequence_pred, y = mean), color = "darkorchid1") +
  geom_ribbon(data = pred_IS_20_39,aes(ymin = X5., ymax = X95.,
                                       y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "darkorchid1", alpha = 0.35) +
  geom_point(data = IS_dataset, aes(x = time_sequence_pred, y = Group2), color = "darkorchid1") +
  
  geom_line(data = pred_IS_40_59, aes(x = time_sequence_pred, y = mean), color = "firebrick1") +
  geom_ribbon(data = pred_IS_40_59,aes(ymin = X5., ymax = X95.,
                                       y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "firebrick1", alpha = 0.35) +
  geom_point(data = IS_dataset, aes(x = time_sequence_pred, y = Group3), color = "firebrick1") +
  
  geom_line(data = pred_IS_60_79, aes(x = time_sequence_pred, y = mean), color = "green") +
  geom_ribbon(data = pred_IS_60_79,aes(ymin = X5., ymax = X95.,
                                       y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "green", alpha = 0.35) +
  geom_point(data = IS_dataset, aes(x = time_sequence_pred, y = Group4), color = "green") +
  
  geom_line(data = pred_IS_over80, aes(x = time_sequence_pred, y = mean), color = "grey") +
  geom_ribbon(data = pred_IS_over80,aes(ymin = X5., ymax = X95.,
                                        y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "grey", alpha = 0.35) +
  geom_point(data = IS_dataset, aes(x = time_sequence_pred, y = Group5), color = "grey") +
  
  xlab('Dates') +
  ylab('Symptomatics')+
  xlim(0,100)+
  ylim(0,1000)+
  theme(legend.position = "right")


p_H = ggplot() + 
  geom_line(data = pred_H_0_19, aes(x = time_sequence_pred, y = mean), color = "cornflowerblue") +
  geom_ribbon(data = pred_H_0_19,aes(ymin = X5., ymax = X95.,
                                     y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "cornflowerblue", alpha = 0.35) +
  geom_point(data = H_dataset, aes(x = time_sequence_pred, y = Group1), color = "cornflowerblue") +
  
  geom_line(data = pred_H_20_39, aes(x = time_sequence_pred, y = mean), color = "darkorchid1") +
  geom_ribbon(data = pred_H_20_39,aes(ymin = X5., ymax = X95.,
                                      y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "darkorchid1", alpha = 0.35) +
  geom_point(data = H_dataset, aes(x = time_sequence_pred, y = Group2), color = "darkorchid1") +
  
  geom_line(data = pred_H_40_59, aes(x = time_sequence_pred, y = mean), color = "firebrick1") +
  geom_ribbon(data = pred_H_40_59,aes(ymin = X5., ymax = X95.,
                                      y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "firebrick1", alpha = 0.35) +
  geom_point(data = H_dataset, aes(x = time_sequence_pred, y = Group3), color = "firebrick1") +
  
  geom_line(data = pred_H_60_79, aes(x = time_sequence_pred, y = mean), color = "green") +
  geom_ribbon(data = pred_H_60_79,aes(ymin = X5., ymax = X95.,
                                      y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "green", alpha = 0.35) +
  geom_point(data = H_dataset, aes(x = time_sequence_pred, y = Group4), color = "green") +
  
  geom_line(data = pred_H_over80, aes(x = time_sequence_pred, y = mean), color = "grey") +
  geom_ribbon(data = pred_H_over80,aes(ymin = X5., ymax = X95.,
                                       y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "grey", alpha = 0.35) +
  geom_point(data = H_dataset, aes(x = time_sequence_pred, y = Group5), color = "grey") +
  xlab('Dates') +
  ylab('Hospitalized')+
  xlim(0,150)+
  ylim(0,600)+
  theme(legend.position = "right")


p_IC = ggplot() + 
  geom_line(data = pred_IC_0_19, aes(x = time_sequence_pred, y = mean), color = "cornflowerblue") +
  geom_ribbon(data = pred_IC_0_19,aes(ymin = X5., ymax = X95.,
                                      y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "cornflowerblue", alpha = 0.35) +
  geom_point(data = IC_dataset, aes(x = time_sequence_pred, y = Group1), color = "cornflowerblue") +
  
  geom_line(data = pred_IC_20_39, aes(x = time_sequence_pred, y = mean), color = "darkorchid1") +
  geom_ribbon(data = pred_IC_20_39,aes(ymin = X5., ymax = X95.,
                                       y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "darkorchid1", alpha = 0.35) +
  geom_point(data = IC_dataset, aes(x = time_sequence_pred, y = Group2), color = "darkorchid1") +
  
  geom_line(data = pred_IC_40_59, aes(x = time_sequence_pred, y = mean), color = "firebrick1") +
  geom_ribbon(data = pred_IC_40_59,aes(ymin = X5., ymax = X95.,
                                       y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "firebrick1", alpha = 0.35) +
  geom_point(data = IC_dataset, aes(x = time_sequence_pred, y = Group3), color = "firebrick1") +
  
  geom_line(data = pred_IC_60_79, aes(x = time_sequence_pred, y = mean), color = "green") +
  geom_ribbon(data = pred_IC_60_79,aes(ymin = X5., ymax = X95.,
                                       y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "green", alpha = 0.35) +
  geom_point(data = IC_dataset, aes(x = time_sequence_pred, y = Group4), color = "green") +
  
  geom_line(data = pred_IC_over80, aes(x = time_sequence_pred, y = mean), color = "grey") +
  geom_ribbon(data = pred_IC_over80,aes(ymin = X5., ymax = X95.,
                                        y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "grey", alpha = 0.35) +
  geom_point(data = IC_dataset, aes(x = time_sequence_pred, y = Group5), color = "grey") +
  xlab('Dates') +
  ylab('Intensive Care')+
  xlim(0,150)+
  ylim(0,100)+
  theme(legend.position = "right")


p_D = ggplot() + 
  geom_line(data = pred_D_0_19, aes(x = time_sequence_pred, y = mean), color = "cornflowerblue") +
  geom_ribbon(data = pred_D_0_19,aes(ymin = X5., ymax = X95.,
                                     y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "cornflowerblue", alpha = 0.35) +
  geom_point(data = D_dataset, aes(x = time_sequence_pred, y = Group1), color = "cornflowerblue") +
  
  geom_line(data = pred_D_20_39, aes(x = time_sequence_pred, y = mean), color = "darkorchid1") +
  geom_ribbon(data = pred_D_20_39,aes(ymin = X5., ymax = X95.,
                                      y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "darkorchid1", alpha = 0.35) +
  geom_point(data = D_dataset, aes(x = time_sequence_pred, y = Group2), color = "darkorchid1") +
  
  geom_line(data = pred_D_40_59, aes(x = time_sequence_pred, y = mean), color = "firebrick1") +
  geom_ribbon(data = pred_D_40_59,aes(ymin = X5., ymax = X95.,
                                      y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "firebrick1", alpha = 0.35) +
  geom_point(data = D_dataset, aes(x = time_sequence_pred, y = Group3), color = "firebrick1") +
  
  geom_line(data = pred_D_60_79, aes(x = time_sequence_pred, y = mean), color = "green") +
  geom_ribbon(data = pred_D_60_79,aes(ymin = X5., ymax = X95.,
                                      y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "green", alpha = 0.35) +
  geom_point(data = D_dataset, aes(x = time_sequence_pred, y = Group4), color = "green") +
  
  geom_line(data = pred_D_over80, aes(x = time_sequence_pred, y = mean), color = "grey") +
  geom_ribbon(data = pred_D_over80,aes(ymin = X5., ymax = X95.,
                                       y = mean, xmin = 0, xmax = n_fitting,x = time_sequence_pred ), fill = "grey", alpha = 0.35) +
  geom_point(data = D_dataset, aes(x = time_sequence_pred, y = Group5), color = "grey") +
  xlab('Dates') +
  ylab('Deaths')+
  xlim(0,150)+
  ylim(0,250)+
  theme(legend.position = "right")


print(p_IS)

print(p_H)

print(p_IC)

print(p_D)
