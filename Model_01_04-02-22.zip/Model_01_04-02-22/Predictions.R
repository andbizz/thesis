library(deSolve)
library(ggplot2)
library(truncnorm)
library(rstan)
windows.options(record=TRUE)
# Data --------------------------------------------------------------------

data_lombardia <- read.csv('C:/Users/andre/OneDrive/Desktop/Tesi/Dataset/data_lombardia.csv')
data_lombardia <- data.frame(data_lombardia)

start <- "2020-03-01"
end <- "2020-05-31"

data_lombardia_symptomatic <- data_lombardia[which(data_lombardia$type == "symptomatic" ),]

data_lombardia_symptomatic_0_9_values   <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_symptomatic_0_9_values[,1])
index_end <- tail(which(data_lombardia_symptomatic_0_9_values[,1] == end), n = 1)

data_lombardia_symptomatic_0_9_values   <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_symptomatic_10_19_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_symptomatic_20_29_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_symptomatic_30_39_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_symptomatic_40_49_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_symptomatic_50_59_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_symptomatic_60_69_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_symptomatic_70_79_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_symptomatic_80_89_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_symptomatic_over90_values <- data_lombardia_symptomatic[which(data_lombardia_symptomatic$group == "over90"),][index_start:index_end,2]

IS_0_9_data   <- as.integer(data_lombardia_symptomatic_0_9_values) 
IS_10_19_data <- as.integer(data_lombardia_symptomatic_10_19_values) 
IS_20_29_data <- as.integer(data_lombardia_symptomatic_20_29_values) 
IS_30_39_data <- as.integer(data_lombardia_symptomatic_30_39_values) 
IS_40_49_data <- as.integer(data_lombardia_symptomatic_40_49_values) 
IS_50_59_data <- as.integer(data_lombardia_symptomatic_50_59_values) 
IS_60_69_data <- as.integer(data_lombardia_symptomatic_60_69_values) 
IS_70_79_data <- as.integer(data_lombardia_symptomatic_70_79_values) 
IS_80_89_data <- as.integer(data_lombardia_symptomatic_80_89_values) 
IS_over90_data <-as.integer(data_lombardia_symptomatic_over90_values)

data_lombardia_recovered <- data_lombardia[which(data_lombardia$type == "recovered" ),]

data_lombardia_recovered_0_9_values   <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_recovered_0_9_values[,1])
index_end <- tail(which(data_lombardia_recovered_0_9_values[,1] == end), n = 1)

data_lombardia_recovered_0_9_values   <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_recovered_10_19_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_recovered_20_29_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_recovered_30_39_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_recovered_40_49_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_recovered_50_59_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_recovered_60_69_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_recovered_70_79_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_recovered_80_89_values <- data_lombardia_recovered[which(data_lombardia_recovered$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_recovered_over90_values <- data_lombardia_recovered[which(data_lombardia_recovered$group == "over90"),][index_start:index_end,2]

H_0_9_data   <- as.integer(data_lombardia_recovered_0_9_values) 
H_10_19_data <- as.integer(data_lombardia_recovered_10_19_values) 
H_20_29_data <- as.integer(data_lombardia_recovered_20_29_values) 
H_30_39_data <- as.integer(data_lombardia_recovered_30_39_values) 
H_40_49_data <- as.integer(data_lombardia_recovered_40_49_values) 
H_50_59_data <- as.integer(data_lombardia_recovered_50_59_values) 
H_60_69_data <- as.integer(data_lombardia_recovered_60_69_values) 
H_70_79_data <- as.integer(data_lombardia_recovered_70_79_values) 
H_80_89_data <- as.integer(data_lombardia_recovered_80_89_values) 
H_over90_data <-as.integer(data_lombardia_recovered_over90_values) 

data_lombardia_intcare <- data_lombardia[which(data_lombardia$type == "intensive_care" ),]

data_lombardia_intcare_0_9_values   <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_intcare_0_9_values[,1])
index_end <- tail(which(data_lombardia_intcare_0_9_values[,1] == end), n = 1)

data_lombardia_intcare_0_9_values   <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_intcare_10_19_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_intcare_20_29_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_intcare_30_39_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_intcare_40_49_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_intcare_50_59_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_intcare_60_69_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_intcare_70_79_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_intcare_80_89_values <- data_lombardia_intcare[which(data_lombardia_intcare$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_intcare_over90_values <- data_lombardia_intcare[which(data_lombardia_intcare$group == "over90"),][index_start:index_end,2]

IC_0_9_data   <- as.integer(data_lombardia_intcare_0_9_values) 
IC_10_19_data <- as.integer(data_lombardia_intcare_10_19_values) 
IC_20_29_data <- as.integer(data_lombardia_intcare_20_29_values) 
IC_30_39_data <- as.integer(data_lombardia_intcare_30_39_values) 
IC_40_49_data <- as.integer(data_lombardia_intcare_40_49_values) 
IC_50_59_data <- as.integer(data_lombardia_intcare_50_59_values) 
IC_60_69_data <- as.integer(data_lombardia_intcare_60_69_values) 
IC_70_79_data <- as.integer(data_lombardia_intcare_70_79_values) 
IC_80_89_data <- as.integer(data_lombardia_intcare_80_89_values) 
IC_over90_data <-as.integer(data_lombardia_intcare_over90_values) 

data_lombardia_deaths <- data_lombardia[which(data_lombardia$type == "deaths" ),]

data_lombardia_deaths_0_9_values   <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "0-9"   ),]

index_start <- match(start,data_lombardia_deaths_0_9_values[,1])
index_end <- tail(which(data_lombardia_deaths_0_9_values[,1] == end), n = 1)

data_lombardia_deaths_0_9_values   <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "0-9"   ),][index_start:index_end,2]
data_lombardia_deaths_10_19_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "10-19" ),][index_start:index_end,2]
data_lombardia_deaths_20_29_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "20-29" ),][index_start:index_end,2]
data_lombardia_deaths_30_39_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "30-39" ),][index_start:index_end,2]
data_lombardia_deaths_40_49_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "40-49" ),][index_start:index_end,2]
data_lombardia_deaths_50_59_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "50-59" ),][index_start:index_end,2]
data_lombardia_deaths_60_69_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "60-69" ),][index_start:index_end,2]
data_lombardia_deaths_70_79_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "70-79" ),][index_start:index_end,2]
data_lombardia_deaths_80_89_values <- data_lombardia_deaths[which(data_lombardia_deaths$group ==  "80-89" ),][index_start:index_end,2]
data_lombardia_deaths_over90_values <- data_lombardia_deaths[which(data_lombardia_deaths$group == "over90"),][index_start:index_end,2]

D_0_9_data   <- as.integer(data_lombardia_deaths_0_9_values) 
D_10_19_data <- as.integer(data_lombardia_deaths_10_19_values) 
D_20_29_data <- as.integer(data_lombardia_deaths_20_29_values) 
D_30_39_data <- as.integer(data_lombardia_deaths_30_39_values) 
D_40_49_data <- as.integer(data_lombardia_deaths_40_49_values) 
D_50_59_data <- as.integer(data_lombardia_deaths_50_59_values) 
D_60_69_data <- as.integer(data_lombardia_deaths_60_69_values) 
D_70_79_data <- as.integer(data_lombardia_deaths_70_79_values) 
D_80_89_data <- as.integer(data_lombardia_deaths_80_89_values) 
D_over90_data <-as.integer(data_lombardia_deaths_over90_values) 

population_all_regions <- read.csv('C:/Users/andre/OneDrive/Desktop/Tesi/Dataset/regionspopulation.csv')
population_lombardia <- population_all_regions[which(population_all_regions$region == 'lombardia'),]

population_lombardia_0_9_value  <- population_lombardia[which(population_lombardia$group == '0-9'   ),3]
population_lombardia_10_19_value <- population_lombardia[which(population_lombardia$group == '10-19' ),3]
population_lombardia_20_29_value <- population_lombardia[which(population_lombardia$group == '20-29' ),3]
population_lombardia_30_39_value <- population_lombardia[which(population_lombardia$group == '30-39' ),3]
population_lombardia_40_49_value <- population_lombardia[which(population_lombardia$group == '40-49' ),3]
population_lombardia_50_59_value <- population_lombardia[which(population_lombardia$group == '50-59' ),3]
population_lombardia_60_69_value <- population_lombardia[which(population_lombardia$group == '60-69' ),3]
population_lombardia_70_79_value <- population_lombardia[which(population_lombardia$group == '70-79' ),3]
population_lombardia_80_89_value <- population_lombardia[which(population_lombardia$group == '80-89' ),3]
population_lombardia_over90_value <- population_lombardia[which(population_lombardia$group =='over90'),3]

N_0_9_data   <- as.integer(as.numeric(population_lombardia_0_9_value))
N_10_19_data <- as.integer(as.numeric(population_lombardia_10_19_value))
N_20_29_data <- as.integer(as.numeric(population_lombardia_20_29_value))
N_30_39_data <- as.integer(as.numeric(population_lombardia_30_39_value))
N_40_49_data <- as.integer(as.numeric(population_lombardia_40_49_value))
N_50_59_data <- as.integer(as.numeric(population_lombardia_50_59_value))
N_60_69_data <- as.integer(as.numeric(population_lombardia_60_69_value))
N_70_79_data <- as.integer(as.numeric(population_lombardia_70_79_value))
N_80_89_data <- as.integer(as.numeric(population_lombardia_80_89_value))
N_over90_data <-as.integer(as.numeric(population_lombardia_over90_value))

N_data <- c(N_0_9_data+N_10_19_data,N_20_29_data+N_30_39_data,
            N_40_49_data+N_50_59_data,N_60_69_data+N_70_79_data,
            N_80_89_data+N_over90_data)
N_sum <- sum(N_data)

n_fitting <- index_end - index_start + 1

n_seed <- 21

# un dato ogni x

x <- 1
n_simulation <- n_seed + n_fitting + 3
s <- seq(1,n_fitting,x)

n_fitting <- length(s)

IS_0_19_data <-  IS_0_9_data[s] +  IS_10_19_data[s]
IS_20_39_data <-  IS_20_29_data[s] +  IS_30_39_data[s]
IS_40_59_data <-  IS_40_49_data[s] +  IS_50_59_data[s]
IS_60_79_data <-  IS_60_69_data[s] +  IS_70_79_data[s]
IS_over80_data <-  IS_80_89_data[s] +  IS_over90_data[s]
H_0_19_data <- H_0_9_data[s] + H_10_19_data[s]
H_20_39_data <- H_20_29_data[s] + H_30_39_data[s]
H_40_59_data <- H_40_49_data[s] + H_50_59_data[s]
H_60_79_data <- H_60_69_data[s] + H_70_79_data[s]
H_over80_data <- H_80_89_data[s] + H_over90_data[s]
IC_0_19_data <- IC_0_9_data[s] + IC_10_19_data[s]
IC_20_39_data <- IC_20_29_data[s] + IC_30_39_data[s]
IC_40_59_data <- IC_40_49_data[s] + IC_50_59_data[s]
IC_60_79_data <- IC_60_69_data[s] + IC_70_79_data[s]
IC_over80_data <- IC_80_89_data[s] + IC_over90_data[s]
D_0_19_data <- D_0_9_data[s] + D_10_19_data[s]
D_20_39_data <- D_20_29_data[s] + D_30_39_data[s]
D_40_59_data <- D_40_49_data[s] + D_50_59_data[s]
D_60_79_data <- D_60_69_data[s] + D_70_79_data[s]
D_over80_data <- D_80_89_data[s] + D_over90_data[s]

contact_matrix <- read.csv('C:/Users/andre/OneDrive/Desktop/Tesi/Dataset/contact_matrix_2.csv')

rownames(contact_matrix) <- c('0-19','20-39','40-59','60-79','over80')
colnames(contact_matrix) <- c('0-19','20-39','40-59','60-79','over80')
C_matrix <- matrix(rep(0,25),nrow = 5, ncol = 5)
K <- matrix(rep(0,25),nrow = 5, ncol = 5)
for (i in 1:5){
  for (j in 1:5) {
    C_matrix[i,j] <- (N_data[i] * contact_matrix[i,j] + N_data[j] * contact_matrix[j,i] )/(2*N_data[i])
    K[i,j] <- C_matrix[i,j]*N_data[i]/N_data[j]
  }
}

C_matrix <- as.matrix(C_matrix)
ee <- eigen(K)
sr <- max(ee$values)


time_sequence <- seq(0, n_simulation, by = x)
initial_time = 0 
time_sequence <- time_sequence[-1]

IS_dataset <- data.frame(0:(length(IS_0_19_data)-1)+n_seed,IS_0_19_data, IS_20_39_data, IS_40_59_data,
                         IS_60_79_data, IS_over80_data)

colnames(IS_dataset) <- c('time_sequence','Group1','Group2','Group3','Group4','Group5')

H_dataset <- data.frame(0:(length(H_0_19_data)-1)+n_seed,H_0_19_data, H_20_39_data, H_40_59_data,
                        H_60_79_data, H_over80_data)

colnames(H_dataset) <- c('time_sequence','Group1','Group2','Group3','Group4','Group5')

IC_dataset <- data.frame(0:(length(H_0_19_data)-1)+n_seed,IC_0_19_data, IC_20_39_data, IC_40_59_data,
                         IC_60_79_data, IC_over80_data)

colnames(IC_dataset) <- c('time_sequence','Group1','Group2','Group3','Group4','Group5')

D_dataset <- data.frame(0:(length(H_0_19_data)-1)+n_seed,D_0_19_data, D_20_39_data, D_40_59_data,
                        D_60_79_data, D_over80_data)
colnames(D_dataset) <- c('time_sequence','Group1','Group2','Group3','Group4','Group5')



# Fixed Parameters --------------------------------------------------------------

r_P <- 0.8537
r_S <- 1
r_A <- 0.5854
sigma <- 1/3.69
eta <- 1/(5.2-3.69)
xi_0_19 <- 18.09/100
xi_20_39 <- 22.41/100 
xi_40_59 <- 30.54/100 
xi_60_79 <- 35.46/100
xi_over80 <- 64.56/100
phi_0_19 <-   0 
phi_20_39 <-  0.0007335988
phi_40_59 <-  0.0251613651
phi_60_79 <-  0.2475838115 
phi_over80 <- 0.3580865420
gamma_H_0_19 <- 1/3 
gamma_H_20_39 <- 1/6.8 
gamma_H_40_59 <- 1/6.8 
gamma_H_60_79 <- 1/5.8 
gamma_H_over80 <- 1/3.9
gamma_R <- 1/2.4
delta_IC <- 1/3 
delta_D <- 1/6
delta_R <- 1/11
epsilon <- 0.05009 
mu <- 0.2
alpha_0_19 <-   0 
alpha_over80 <- 0
psi_0_19 <-   0 
psi_20_39 <-   0 

# Equations --------------------------------------------------------------

equations <- function(time, variables, parameters){
  
  t = time;
  
  S_0_19 =  variables[1];
  E_0_19 =  variables[2];
  P_0_19 = variables[3];
  IS_0_19 =  variables[4];
  IA_0_19 =  variables[5];
  H_0_19 = variables[6];
  IC_0_19 = variables[7];
  
  S_20_39 =  variables[8];
  E_20_39 =  variables[9];
  P_20_39 = variables[10];
  IS_20_39 =  variables[11];
  IA_20_39 =  variables[12];
  H_20_39 = variables[13];
  IC_20_39 = variables[14];
  
  S_40_59 =  variables[15];
  E_40_59 =  variables[16];
  P_40_59 = variables[17];
  IS_40_59 =  variables[18];
  IA_40_59 =  variables[19];
  H_40_59 = variables[20];
  IC_40_59 = variables[21];
  
  S_60_79 =  variables[22];
  E_60_79 =  variables[23];
  P_60_79 = variables[24];
  IS_60_79 =  variables[25];
  IA_60_79 =  variables[26];
  H_60_79 = variables[27];
  IC_60_79 = variables[28];
  
  S_over80 =  variables[29];
  E_over80 =  variables[30];
  P_over80 = variables[31];
  IS_over80 =  variables[32];
  IA_over80 =  variables[33];
  H_over80 = variables[34];
  IC_over80 = variables[35];
  
  beta = parameters[1];
  s = parameters[2];
  l = parameters[3];
  nu = parameters[4];
  omega_0_19 = parameters[5];
  omega_20_39 = parameters[6];
  omega_40_59 = parameters[7];
  omega_60_79 = parameters[8];
  omega_over80 = parameters[9];
  gamma_D_0_19 = parameters[10];
  gamma_D_20_39 = parameters[11];
  gamma_D_40_59 = parameters[12];
  gamma_D_60_79 = parameters[13];
  gamma_D_over80 = parameters[14]; 
  alpha_20_39 = parameters[15];
  alpha_40_59 = parameters[16];
  alpha_60_79 = parameters[17];
  psi_40_59 = parameters[18];
  psi_60_79 = parameters[19];
  psi_over80 = parameters[20];
  rho_0_19 = parameters[21];
  rho_20_39 = parameters[22];
  rho_40_59 = parameters[23];
  rho_60_79 = parameters[24];
  rho_over80 = parameters[25];
  if ((n_seed-7) <= t ){
    c_0_19_0_19  = C_matrix[1,1] * s
    c_0_19_20_39 = C_matrix[1,2] * s
    c_20_39_0_19 = C_matrix[2,1] * s
    c_20_39_20_39 = C_matrix[2,2] * s}
  else {
    c_0_19_0_19  = C_matrix[1,1]
    c_0_19_20_39 = C_matrix[1,2]
    c_20_39_0_19 = C_matrix[2,1]
    c_20_39_20_39 = C_matrix[2,2]}
  
  
  
  c_0_19_40_59 = C_matrix[1,3];
  c_0_19_60_79 = C_matrix[1,4];
  c_0_19_over80 = C_matrix[1,5];
  
  c_20_39_40_59 = C_matrix[2,3];
  c_20_39_60_79 = C_matrix[2,4];
  c_20_39_over80 = C_matrix[2,5];
  
  c_40_59_0_19 = C_matrix[3,1];
  c_40_59_20_39 = C_matrix[3,2];
  c_40_59_40_59 = C_matrix[3,3];
  c_40_59_60_79 = C_matrix[3,4];
  c_40_59_over80 = C_matrix[3,5];
  
  c_60_79_0_19 = C_matrix[4,1];
  c_60_79_20_39 = C_matrix[4,2];
  c_60_79_40_59 = C_matrix[4,3];
  c_60_79_60_79 = C_matrix[4,4];
  c_60_79_over80 = C_matrix[4,5];
  
  c_over80_0_19 = C_matrix[5,1];
  c_over80_20_39 = C_matrix[5,2];
  c_over80_40_59 = C_matrix[5,3];
  c_over80_60_79 = C_matrix[5,4];
  c_over80_over80 = C_matrix[5,5];
  
  N_0_19 = N_data[1];
  N_20_39 = N_data[2];
  N_40_59 = N_data[3];
  N_60_79 = N_data[4];
  N_over80 = N_data[5];
  
  
  if ((t > (n_seed+10)) && (t < (n_seed + 65)))
  { beta =   beta * (1 - l) ; }
  else if (t >(n_seed+64))
  { beta =  beta * (1 - nu) ; }
  else 
  { beta =  beta; }
  
  lambda_0_19 =  beta * (c_0_19_0_19   * (r_P * P_0_19   + r_S * (1-rho_0_19) * IS_0_19   + r_A * IA_0_19)   / N_0_19+ c_0_19_20_39  * (r_P * P_20_39  + r_S * (1-rho_20_39) * IS_20_39  + r_A * IA_20_39)  / N_20_39+ c_0_19_40_59  * (r_P * P_40_59  + r_S * (1-rho_40_59) * IS_40_59  + r_A * IA_40_59)  / N_40_59 + c_0_19_60_79  * (r_P * P_60_79  + r_S * (1-rho_60_79) * IS_60_79  + r_A * IA_60_79)  / N_60_79+ c_0_19_over80 * (r_P * P_over80 + r_S * (1-rho_over80) * IS_over80 + r_A * IA_over80) / N_over80) ;
  
  lambda_20_39 = beta * (c_20_39_0_19   * (r_P * P_0_19   + r_S * (1-rho_0_19) *  IS_0_19   + r_A * IA_0_19)   / N_0_19+ c_20_39_20_39  * (r_P * P_20_39  + r_S * (1-rho_20_39) * IS_20_39  + r_A * IA_20_39)  / N_20_39+ c_20_39_40_59  * (r_P * P_40_59  + r_S * (1-rho_40_59) * IS_40_59  + r_A * IA_40_59)  / N_40_59+ c_20_39_60_79  * (r_P * P_60_79  + r_S * (1-rho_60_79) * IS_60_79  + r_A * IA_60_79)  / N_60_79+ c_20_39_over80 * (r_P * P_over80 + r_S * (1-rho_over80) * IS_over80 + r_A * IA_over80) / N_over80) ;
  
  lambda_40_59 = beta * (c_40_59_0_19   * (r_P * P_0_19   + r_S * (1-rho_0_19) *  IS_0_19   + r_A * IA_0_19)   / N_0_19 + c_40_59_20_39  * (r_P * P_20_39  + r_S * (1-rho_20_39) * IS_20_39  + r_A * IA_20_39)  / N_20_39+ c_40_59_40_59  * (r_P * P_40_59  + r_S * (1-rho_40_59) * IS_40_59  + r_A * IA_40_59)  / N_40_59 + c_40_59_60_79  * (r_P * P_60_79  + r_S * (1-rho_60_79) * IS_60_79  + r_A * IA_60_79)  / N_60_79+ c_40_59_over80 * (r_P * P_over80 + r_S * (1-rho_over80) * IS_over80 + r_A * IA_over80) / N_over80) ;
  
  lambda_60_79 = beta * (c_60_79_0_19   * (r_P * P_0_19   + r_S * (1-rho_0_19) *  IS_0_19   + r_A * IA_0_19)   / N_0_19 + c_60_79_20_39  * (r_P * P_20_39  + r_S * (1-rho_20_39) * IS_20_39  + r_A * IA_20_39)  / N_20_39+ c_60_79_40_59  * (r_P * P_40_59  + r_S * (1-rho_40_59) * IS_40_59  + r_A * IA_40_59)  / N_40_59+ c_60_79_60_79  * (r_P * P_60_79  + r_S * (1-rho_60_79) * IS_60_79  + r_A * IA_60_79)  / N_60_79+ c_60_79_over80 * (r_P * P_over80 + r_S * (1-rho_over80) * IS_over80 + r_A * IA_over80) / N_over80) ;
  
  lambda_over80 = beta * (c_over80_0_19   * (r_P * P_0_19   + r_S * (1-rho_0_19) *  IS_0_19   + r_A * IA_0_19)   / N_0_19 + c_over80_20_39  * (r_P * P_20_39  + r_S * (1-rho_20_39) * IS_20_39  + r_A * IA_20_39)  / N_20_39+ c_over80_40_59  * (r_P * P_40_59  + r_S * (1-rho_40_59) * IS_40_59  + r_A * IA_40_59)  / N_40_59 + c_over80_60_79  * (r_P * P_60_79  + r_S * (1-rho_60_79) * IS_60_79  + r_A * IA_60_79)  / N_60_79 + c_over80_over80 * (r_P * P_over80 + r_S * (1-rho_over80) * IS_over80 + r_A * IA_over80) / N_over80) ;
  
  dS_0_19_dt = - lambda_0_19 * S_0_19              ;
  dE_0_19_dt = + lambda_0_19 * S_0_19 - sigma * E_0_19;
  dP_0_19_dt = + sigma * E_0_19 - eta * P_0_19;
  dIS_0_19_dt = + eta * xi_0_19 * P_0_19 - gamma_D_0_19 * phi_0_19 * (1-omega_0_19) * IS_0_19 - gamma_H_0_19 * omega_0_19 * IS_0_19 - gamma_R * (1-phi_0_19) * (1-omega_0_19) * IS_0_19;
  dIA_0_19_dt = + eta * (1-xi_0_19) * P_0_19 - gamma_R * IA_0_19;
  dH_0_19_dt =  + gamma_H_0_19 * omega_0_19 * IS_0_19 - delta_D  * psi_0_19 * (1-alpha_0_19) * H_0_19 - delta_IC * alpha_0_19 * H_0_19 - delta_R * ( 1 - psi_0_19 )*(1 - alpha_0_19) * H_0_19 + epsilon * IC_0_19;
  dIC_0_19_dt = + delta_IC * alpha_0_19 * H_0_19 - mu * IC_0_19 - epsilon * IC_0_19;
  
  dS_20_39_dt = - lambda_20_39 * S_20_39              ;
  dE_20_39_dt = + lambda_20_39 * S_20_39 - sigma * E_20_39;
  dP_20_39_dt = + sigma * E_20_39 - eta * P_20_39;
  dIS_20_39_dt = + eta * xi_20_39 * P_20_39 - gamma_D_20_39 * phi_20_39 * (1-omega_20_39) * IS_20_39 - gamma_H_20_39 * omega_20_39 * IS_20_39 - gamma_R * (1-phi_20_39) * (1-omega_20_39) * IS_20_39;
  dIA_20_39_dt = + eta * (1-xi_20_39) * P_20_39 - gamma_R * IA_20_39;
  dH_20_39_dt =  + gamma_H_20_39 * omega_20_39 * IS_20_39 - delta_D  * (1-alpha_20_39) * psi_20_39 * H_20_39 - delta_IC * alpha_20_39 * H_20_39 - delta_R * (1-psi_20_39) * (1 - alpha_20_39) * H_20_39 + epsilon * IC_20_39;
  dIC_20_39_dt = + delta_IC * alpha_20_39 * H_20_39 - mu * IC_20_39 - epsilon * IC_20_39;
  
  dS_40_59_dt = - lambda_40_59 * S_40_59              ;
  dE_40_59_dt = + lambda_40_59 * S_40_59 - sigma * E_40_59;
  dP_40_59_dt = + sigma * E_40_59 - eta * P_40_59;
  dIS_40_59_dt = + eta * xi_40_59 * P_40_59 - gamma_D_40_59 * phi_40_59 * (1-omega_40_59) * IS_40_59 - gamma_H_40_59 * omega_40_59 * IS_40_59 - gamma_R * (1-phi_40_59) * (1-omega_40_59) * IS_40_59;
  dIA_40_59_dt = + eta * (1-xi_40_59) * P_40_59 - gamma_R * IA_40_59;
  dH_40_59_dt =  + gamma_H_40_59 * omega_40_59 * IS_40_59 - delta_D  * (1-alpha_40_59) * psi_40_59 * H_40_59 - delta_IC * alpha_40_59 * H_40_59 - delta_R * ( 1 - psi_40_59) * ( 1 - alpha_40_59) * H_40_59 + epsilon * IC_40_59;
  dIC_40_59_dt = + delta_IC * alpha_40_59 * H_40_59 - mu * IC_40_59 - epsilon * IC_40_59;
  
  
  dS_60_79_dt = - lambda_60_79 * S_60_79              ;
  dE_60_79_dt = + lambda_60_79 * S_60_79 - sigma * E_60_79;
  dP_60_79_dt = + sigma * E_60_79 - eta * P_60_79;
  dIS_60_79_dt = + eta * xi_60_79 * P_60_79 - gamma_D_60_79 * phi_60_79 * (1-omega_60_79) * IS_60_79 - gamma_H_60_79 * omega_60_79 * IS_60_79 - gamma_R * (1-phi_60_79) * (1-omega_60_79) * IS_60_79;
  dIA_60_79_dt = + eta * (1-xi_60_79) * P_60_79 - gamma_R * IA_60_79;
  dH_60_79_dt =  + gamma_H_60_79 * omega_60_79 * IS_60_79 - delta_D  * (1-alpha_60_79) * psi_60_79 * H_60_79 - delta_IC * alpha_60_79 * H_60_79 - delta_R * (1-psi_60_79) * ( 1 - alpha_60_79) * H_60_79 + epsilon * IC_60_79;
  dIC_60_79_dt = + delta_IC * alpha_60_79 * H_60_79 - mu * IC_60_79 - epsilon * IC_60_79;
  
  
  dS_over80_dt = - lambda_over80 * S_over80              ;
  dE_over80_dt = + lambda_over80 * S_over80 - sigma * E_over80;
  dP_over80_dt = + sigma * E_over80 - eta * P_over80;
  dIS_over80_dt = + eta * xi_over80 * P_over80 - gamma_D_over80 * phi_over80 * (1-omega_over80) * IS_over80 - gamma_H_over80 * omega_over80 * IS_over80 - gamma_R * (1-phi_over80) * (1-omega_over80) * IS_over80;
  dIA_over80_dt = + eta * (1-xi_over80) * P_over80 - gamma_R * IA_over80;
  dH_over80_dt =  + gamma_H_over80 * omega_over80 * IS_over80 - delta_D  * (1-alpha_over80) * psi_over80 * H_over80 - delta_IC * alpha_over80 * H_over80 - delta_R * (1-psi_over80) * (1- alpha_over80) * H_over80 + epsilon * IC_over80;
  dIC_over80_dt = + delta_IC * alpha_over80 * H_over80 - mu * IC_over80 - epsilon * IC_over80;
  
  
  return(list(c(dS_0_19_dt, dE_0_19_dt, dP_0_19_dt, dIS_0_19_dt,dIA_0_19_dt, dH_0_19_dt, dIC_0_19_dt, 
                dS_20_39_dt, dE_20_39_dt,dP_20_39_dt, dIS_20_39_dt,dIA_20_39_dt,dH_20_39_dt,dIC_20_39_dt,
                dS_40_59_dt, dE_40_59_dt,dP_40_59_dt,  dIS_40_59_dt,dIA_40_59_dt, dH_40_59_dt, dIC_40_59_dt,
                dS_60_79_dt, dE_60_79_dt,dP_60_79_dt, dIS_60_79_dt,dIA_60_79_dt, dH_60_79_dt,dIC_60_79_dt,
                dS_over80_dt, dE_over80_dt,dP_over80_dt, dIS_over80_dt,dIA_over80_dt, dH_over80_dt,dIC_over80_dt)));
  
  
}

# Estimated Parameters --------------------------------------------------------------


# beta_vec <-         rtruncnorm(2000, a=0.046, b=0.048, mean = 0.047, sd = 0.000005)
# s_vec <-            rtruncnorm(2000, a=0.05,  b=0.15, mean = 0.1, sd = 0.00000005)
# l_vec <-            rtruncnorm(2000, a=0.5,  b=1, mean = 0.7, sd = 0.00000005)
# nu_vec<-            rtruncnorm(2000, a=0.5,  b=1, mean = 0.7, sd = 0.00000005)
# 
# omega_0_19_vec <-   rtruncnorm(2000, a=0,     b=0.05, mean = 0.01, sd = 0.00005)
# omega_20_39_vec <-  rtruncnorm(2000, a=0.1,   b=0.2, mean = 0.175, sd = 0.00005)
# omega_40_59_vec <-  rtruncnorm(2000, a=0.25,   b=0.35, mean = 0.35, sd = 0.00005)
# omega_60_79_vec <-  rtruncnorm(2000, a=0.6,   b=0.7, mean = 0.65, sd = 0.00005)
# omega_over80_vec <- rtruncnorm(2000, a=0.65,  b=0.75, mean = 0.6, sd = 0.00005)
# 
# gamma_D_0_19_vec <-     rtruncnorm(2000, a=1/100 ,   b=1/2 , mean = 1/56,   sd = 0.00005)
# gamma_D_20_39_vec <-    rtruncnorm(2000, a=1/80 ,   b=1/2 , mean = 1/33 ,  sd = 0.00005)
# gamma_D_40_59_vec <-    rtruncnorm(2000, a=1/21 ,   b=1/2 , mean = 1/33 ,  sd = 0.00005)
# gamma_D_60_79_vec <-    rtruncnorm(2000, a=1/21 ,   b=1/2 , mean = 1/14 ,  sd = 0.00005)
# gamma_D_over80_vec <-   rtruncnorm(2000, a=1/21 ,   b=1/2 , mean = 1/7 ,  sd = 0.00005)
# 
# alpha_0_19_vec <-   rtruncnorm(2000, a=0,         b=0.001/100,   mean = 0/100, sd = 0.000000005)
# alpha_20_39_vec <-  rtruncnorm(2000, a=1/100,     b=5/100,   mean = 2/100, sd = 0.000000005)
# alpha_40_59_vec <-  rtruncnorm(2000, a=2/100,     b=5/100,   mean = 4.5/100, sd = 0.000000005)
# alpha_60_79_vec <-  rtruncnorm(2000, a=2/100,     b=5/100,   mean = 4/100, sd = 0.000000005)
# alpha_over80_vec <- rtruncnorm(2000, a=0/100,     b=0.001/100,   mean = 0/100, sd = 0.000000005)
# 
# psi_0_19_vec <-     rtruncnorm(2000, a=0,   b=0.001, mean = 0/100, sd = 0.0000005)
# psi_20_39_vec <-    rtruncnorm(2000, a=0,   b=1, mean = 1/100, sd = 0.0000005)
# psi_40_59_vec <-    rtruncnorm(2000, a=0,   b=1, mean = 1/100, sd = 0.0000005)
# psi_60_79_vec <-    rtruncnorm(2000, a=0,   b=1, mean = 15/100, sd = 0.0000005)
# psi_over80_vec <-   rtruncnorm(2000, a=0,   b=1, mean = 45/100, sd = 0.0000005)
# 
# rho_0_19_vec <-     rtruncnorm(2000, a=0,     b=0.1, mean = 0.05, sd = 0.0005)
# rho_20_39_vec <-    rtruncnorm(2000, a=0.15,  b=0.25, mean = 0.2, sd = 0.0005)
# rho_40_59_vec <-    rtruncnorm(2000, a=0.2,   b=0.35, mean = 0.25, sd = 0.0005)
# rho_60_79_vec <-    rtruncnorm(2000, a=0.45,   b=0.6, mean = 0.5, sd = 0.0005)
# rho_over80_vec <-   rtruncnorm(2000, a=0.7,   b=0.8, mean = 0.75, sd = 0.0005)
# 
# iA0_vec <-           rtruncnorm(2000, a=100, b=10000, mean = 3000, sd = 1)
# 
# 
# 
# parameters_samples <- cbind(beta_vec, s_vec, l_vec, nu_vec,
#                             omega_0_19_vec,omega_20_39_vec,omega_40_59_vec,omega_60_79_vec, omega_over80_vec,
#                             gamma_D_0_19_vec,gamma_D_20_39_vec,gamma_D_40_59_vec,gamma_D_60_79_vec, gamma_D_over80_vec,
#                             alpha_0_19_vec,alpha_20_39_vec,alpha_40_59_vec,alpha_60_79_vec, alpha_over80_vec,
#                             psi_0_19_vec,psi_20_39_vec,psi_40_59_vec,psi_60_79_vec, psi_over80_vec,
#                             rho_0_19_vec,rho_20_39_vec,rho_40_59_vec,rho_60_79_vec, rho_over80_vec,
#                             iA0_vec
#                             )

parameters_samples <- read.csv("parameters_samples.csv")

# Simulation --------------------------------------------------------------

n_sim <- 300
time_values <- seq(1,n_sim)
traj_numb <- 100
number_samples <- dim(parameters_samples)[1]/2 #la prim� met� � di burn-up

rand_traj <- sample(1:number_samples,traj_numb)+number_samples

par_samp <- parameters_samples[rand_traj,]

IS_inc_ave_0_19 <- rep(0,n_sim)
IS_inc_ave_20_39 <- rep(0,n_sim)
IS_inc_ave_40_59 <- rep(0,n_sim)
IS_inc_ave_60_79 <- rep(0,n_sim)
IS_inc_ave_over80 <- rep(0,n_sim)

H_inc_ave_0_19 <- rep(0,n_sim)
H_inc_ave_20_39 <- rep(0,n_sim)
H_inc_ave_40_59 <- rep(0,n_sim)
H_inc_ave_60_79 <- rep(0,n_sim)
H_inc_ave_over80 <- rep(0,n_sim)

IC_inc_ave_0_19 <- rep(0,n_sim)
IC_inc_ave_20_39 <- rep(0,n_sim)
IC_inc_ave_40_59 <- rep(0,n_sim)
IC_inc_ave_60_79 <- rep(0,n_sim)
IC_inc_ave_over80 <- rep(0,n_sim)

D_inc_ave_0_19 <- rep(0,n_sim)
D_inc_ave_20_39 <- rep(0,n_sim)
D_inc_ave_40_59 <- rep(0,n_sim)
D_inc_ave_60_79 <- rep(0,n_sim)
D_inc_ave_over80 <- rep(0,n_sim)

IS_inc_traj_0_19 <- rep(0,n_sim)
IS_inc_traj_20_39 <- rep(0,n_sim)
IS_inc_traj_40_59 <- rep(0,n_sim)
IS_inc_traj_60_79 <- rep(0,n_sim)
IS_inc_traj_over80 <- rep(0,n_sim)

H_inc_traj_0_19 <- rep(0,n_sim)
H_inc_traj_20_39 <- rep(0,n_sim)
H_inc_traj_40_59 <- rep(0,n_sim)
H_inc_traj_60_79 <- rep(0,n_sim)
H_inc_traj_over80 <- rep(0,n_sim)

IC_inc_traj_0_19 <- rep(0,n_sim)
IC_inc_traj_20_39 <- rep(0,n_sim)
IC_inc_traj_40_59 <- rep(0,n_sim)
IC_inc_traj_60_79 <- rep(0,n_sim)
IC_inc_traj_over80 <- rep(0,n_sim)

D_inc_traj_0_19 <- rep(0,n_sim)
D_inc_traj_20_39 <- rep(0,n_sim)
D_inc_traj_40_59 <- rep(0,n_sim)
D_inc_traj_60_79 <- rep(0,n_sim)
D_inc_traj_over80 <- rep(0,n_sim)

IS_acc_traj_0_19 <- rep(0,n_sim)
IS_acc_traj_20_39 <- rep(0,n_sim)
IS_acc_traj_40_59 <- rep(0,n_sim)
IS_acc_traj_60_79 <- rep(0,n_sim)
IS_acc_traj_over80 <- rep(0,n_sim)

H_acc_traj_0_19 <- rep(0,n_sim)
H_acc_traj_20_39 <- rep(0,n_sim)
H_acc_traj_40_59 <- rep(0,n_sim)
H_acc_traj_60_79 <- rep(0,n_sim)
H_acc_traj_over80 <- rep(0,n_sim)

IC_acc_traj_0_19 <- rep(0,n_sim)
IC_acc_traj_20_39 <- rep(0,n_sim)
IC_acc_traj_40_59 <- rep(0,n_sim)
IC_acc_traj_60_79 <- rep(0,n_sim)
IC_acc_traj_over80 <- rep(0,n_sim)

D_acc_traj_0_19 <- rep(0,n_sim)
D_acc_traj_20_39 <- rep(0,n_sim)
D_acc_traj_40_59 <- rep(0,n_sim)
D_acc_traj_60_79 <- rep(0,n_sim)
D_acc_traj_over80 <- rep(0,n_sim)

S_traj_0_19 <- rep(0,n_sim)
S_traj_20_39 <- rep(0,n_sim)
S_traj_40_59 <- rep(0,n_sim)
S_traj_60_79 <- rep(0,n_sim)
S_traj_over80 <- rep(0,n_sim)

E_traj_0_19 <- rep(0,n_sim)
E_traj_20_39 <- rep(0,n_sim)
E_traj_40_59 <- rep(0,n_sim)
E_traj_60_79 <- rep(0,n_sim)
E_traj_over80 <- rep(0,n_sim)

P_traj_0_19 <- rep(0,n_sim)
P_traj_20_39 <- rep(0,n_sim)
P_traj_40_59 <- rep(0,n_sim)
P_traj_60_79 <- rep(0,n_sim)
P_traj_over80 <- rep(0,n_sim)

IS_traj_0_19 <- rep(0,n_sim)
IS_traj_20_39 <- rep(0,n_sim)
IS_traj_40_59 <- rep(0,n_sim)
IS_traj_60_79 <- rep(0,n_sim)
IS_traj_over80 <- rep(0,n_sim)

IA_traj_0_19 <- rep(0,n_sim)
IA_traj_20_39 <- rep(0,n_sim)
IA_traj_40_59 <- rep(0,n_sim)
IA_traj_60_79 <- rep(0,n_sim)
IA_traj_over80 <- rep(0,n_sim)

H_traj_0_19 <- rep(0,n_sim)
H_traj_20_39 <- rep(0,n_sim)
H_traj_40_59 <- rep(0,n_sim)
H_traj_60_79 <- rep(0,n_sim)
H_traj_over80 <- rep(0,n_sim)

IC_traj_0_19 <- rep(0,n_sim)
IC_traj_20_39 <- rep(0,n_sim)
IC_traj_40_59 <- rep(0,n_sim)
IC_traj_60_79 <- rep(0,n_sim)
IC_traj_over80 <- rep(0,n_sim)

R0_eff_vec <- rep(0,traj_numb)

for (i in 1:traj_numb) {
  
  beta = par_samp[i,1];
  s = par_samp[i,2];
  l = par_samp[i,3];
  nu = par_samp[i,4];
  omega_0_19 = par_samp[i,5];
  omega_20_39 = par_samp[i,6];
  omega_40_59 = par_samp[i,7];
  omega_60_79 = par_samp[i,8];
  omega_over80 = par_samp[i,9];
  gamma_D_0_19 = par_samp[i,10];
  gamma_D_20_39 = par_samp[i,11];
  gamma_D_40_59 = par_samp[i,12];
  gamma_D_60_79 = par_samp[i,13];
  gamma_D_over80 = par_samp[i,14]; 
  alpha_20_39 = par_samp[i,15];
  alpha_40_59 = par_samp[i,16];
  alpha_60_79 = par_samp[i,17];
  psi_40_59 = par_samp[i,18];
  psi_60_79 = par_samp[i,19];
  psi_over80 = par_samp[i,20];
  rho_0_19 = par_samp[i,21];
  rho_20_39 = par_samp[i,22];
  rho_40_59 = par_samp[i,23];
  rho_60_79 = par_samp[i,24];
  rho_over80 = par_samp[i,25]; 
  iA0 = par_samp[i,26];
  
  theta_0_19   = gamma_D_0_19   * phi_0_19  * (1-omega_0_19)  + gamma_H_0_19   * omega_0_19   + gamma_R * (1- omega_0_19  )*(1 - phi_0_19);
  theta_20_39  = gamma_D_20_39  * phi_20_39   * (1-omega_20_39)  + gamma_H_20_39  * omega_20_39  + gamma_R * (1- omega_20_39 )*(1 - phi_20_39);
  theta_40_59  = gamma_D_40_59  * phi_40_59   * (1-omega_40_59)  + gamma_H_40_59  * omega_40_59  + gamma_R * (1- omega_40_59 )*(1  - phi_40_59);
  theta_60_79  = gamma_D_60_79  * phi_60_79   * (1-omega_60_79)  + gamma_H_60_79  * omega_60_79  + gamma_R * (1- omega_60_79 )*(1  - phi_60_79);
  theta_over80 = gamma_D_over80 * phi_over80  * (1-omega_over80)  + gamma_H_over80 * omega_over80 + gamma_R * (1- omega_over80  )*(1- phi_over80);
  
  rho_1   = r_P / eta + r_S * xi_0_19 / theta_0_19     + r_A * (1-xi_0_19)/gamma_R;
  rho_2  = r_P / eta + r_S * xi_20_39 / theta_20_39   + r_A * (1-xi_20_39)/gamma_R;
  rho_3  = r_P / eta + r_S * xi_40_59 / theta_40_59   + r_A * (1-xi_40_59)/gamma_R;
  rho_4  = r_P / eta + r_S * xi_60_79 / theta_60_79   + r_A * (1-xi_60_79)/gamma_R;
  rho_5 = r_P / eta + r_S * xi_over80 / theta_over80 + r_A * (1-xi_over80)/gamma_R;
  
  rho_vec = c(rho_1, rho_2, rho_3, rho_4, rho_5)
  
  NGM <- matrix(rep(0,25),nrow = 5, ncol = 5) 
  
  for (q in 1:5) {
    for (w in 1:5) {
      NGM[q,w] <- beta * C_matrix[q,w] * N_data[q]/N_data[w] * rho_vec[w]
    }
  }
  
  NGM_matrix <- as.matrix(NGM)
  eNGM <- eigen(NGM_matrix)
  R0_eff <- max(eNGM$values)
  
  R0_eff_vec[i] <- R0_eff
  
  
  parameters_values <- c(beta = beta,
                         s = s,
                         l = l,
                         nu = nu,
                         omega_0_19 = omega_0_19,
                         omega_20_39 = omega_20_39,
                         omega_40_59 = omega_40_59,
                         omega_60_79 = omega_60_79,
                         omega_over80 = omega_over80,
                         gamma_D_0_19 = gamma_D_0_19,
                         gamma_D_20_39 = gamma_D_20_39,
                         gamma_D_40_59 = gamma_D_40_59,
                         gamma_D_60_79 = gamma_D_60_79,
                         gamma_D_over80 = gamma_D_over80,
                         alpha_20_39 = alpha_20_39,
                         alpha_40_59 = alpha_40_59,
                         alpha_60_79 = alpha_60_79,
                         psi_40_59 = psi_40_59,
                         psi_60_79 = psi_60_79,
                         psi_over80 = psi_over80,
                         rho_0_19 = rho_0_19,
                         rho_20_39 = rho_20_39,
                         rho_40_59 = rho_40_59,
                         rho_60_79 = rho_60_79,
                         rho_over80 = rho_over80,
                         iA0 = iA0
  )   
  
  
  
  initial_values <- c( S_0_19 =  N_data[1]-iA0 * N_data[1]/N_sum,
                       E_0_19 =  0,
                       P_0_19 = 0,
                       IS_0_19 = 0,
                       IA_0_19 =  iA0 * N_data[1]/N_sum,
                       H_0_19 = 0,
                       IC_0_19 = 0,
                       S_20_39 =  N_data[2]-iA0 * N_data[2]/N_sum,
                       E_20_39 =  0,
                       P_20_39 = 0,
                       IS_20_39 = 0,
                       IA_20_39 =  iA0 * N_data[2]/N_sum,
                       H_20_39 = 0,
                       IC_20_39 = 0,
                       S_40_59 =  N_data[3]-iA0 * N_data[3]/N_sum,
                       E_40_59 =  0,
                       P_40_59 = 0,
                       IS_40_59 = 0,
                       IA_40_59 =  iA0 * N_data[3]/N_sum,
                       H_40_59 = 0,
                       IC_40_59 = 0,
                       S_60_79 =  N_data[4]-iA0 * N_data[4]/N_sum,
                       E_60_79 =  0,
                       P_60_79 = 0,
                       IS_60_79 = 0,
                       IA_60_79 =  iA0 * N_data[4]/N_sum,
                       H_60_79 = 0,
                       IC_60_79 = 0,
                       S_over80 =  N_data[5]-iA0 * N_data[5]/N_sum,
                       E_over80 =  0,
                       P_over80 = 0,
                       IS_over80 = 0,
                       IA_over80 =  iA0 * N_data[5]/N_sum,
                       H_over80 = 0,
                       IC_over80 = 0 )
  
  
  
  y_ode <- ode(
    y = initial_values,
    times = time_values,
    func = equations,
    parms = parameters_values
  ) 
  
  IC_0_19 <- rep(0,n_sim)
  IC_20_39 <- rep(0,n_sim)
  IC_40_59 <- rep(0,n_sim)
  IC_60_79 <- rep(0,n_sim)
  IC_over80 <- rep(0,n_sim)
  
  IS_inc_0_19 <- rep(0,n_sim)
  IS_inc_20_39 <- rep(0,n_sim)
  IS_inc_40_59 <- rep(0,n_sim)
  IS_inc_60_79 <- rep(0,n_sim)
  IS_inc_over80 <- rep(0,n_sim)
  
  H_inc_0_19 <- rep(0,n_sim)
  H_inc_20_39 <- rep(0,n_sim)
  H_inc_40_59 <- rep(0,n_sim)
  H_inc_60_79 <- rep(0,n_sim)
  H_inc_over80 <- rep(0,n_sim)
  
  IC_inc_0_19 <- rep(0,n_sim)
  IC_inc_20_39 <- rep(0,n_sim)
  IC_inc_40_59 <- rep(0,n_sim)
  IC_inc_60_79 <- rep(0,n_sim)
  IC_inc_over80 <- rep(0,n_sim)
  
  D_inc_0_19 <- rep(0,n_sim)
  D_inc_20_39 <- rep(0,n_sim)
  D_inc_40_59 <- rep(0,n_sim)
  D_inc_60_79 <- rep(0,n_sim)
  D_inc_over80 <- rep(0,n_sim)
  
  
  IS_acc_0_19 <- rep(0,n_sim)
  IS_acc_20_39 <- rep(0,n_sim)
  IS_acc_40_59 <- rep(0,n_sim)
  IS_acc_60_79 <- rep(0,n_sim)
  IS_acc_over80 <- rep(0,n_sim)
  
  H_acc_0_19 <- rep(0,n_sim)
  H_acc_20_39 <- rep(0,n_sim)
  H_acc_40_59 <- rep(0,n_sim)
  H_acc_60_79 <- rep(0,n_sim)
  H_acc_over80 <- rep(0,n_sim)
  
  IC_acc_0_19 <- rep(0,n_sim)
  IC_acc_20_39 <- rep(0,n_sim)
  IC_acc_40_59 <- rep(0,n_sim)
  IC_acc_60_79 <- rep(0,n_sim)
  IC_acc_over80 <- rep(0,n_sim)
  
  D_acc_0_19 <- rep(0,n_sim)
  D_acc_20_39 <- rep(0,n_sim)
  D_acc_40_59 <- rep(0,n_sim)
  D_acc_60_79 <- rep(0,n_sim)
  D_acc_over80 <- rep(0,n_sim) 
  
  
  for (i in 1:n_sim) {
    
    IS_inc_0_19[i]   = eta * xi_0_19 * y_ode[i,4] * rho_0_19;
    IS_inc_20_39[i]  = eta * xi_20_39 * y_ode[i,11] * rho_20_39 ;
    IS_inc_40_59[i]  = eta * xi_40_59 * y_ode[i,18] * rho_40_59 ;
    IS_inc_60_79[i]  = eta * xi_60_79 * y_ode[i,25] * rho_60_79 ;
    IS_inc_over80[i] = eta * xi_over80 * y_ode[i,32] * rho_over80 ;
    
    H_inc_0_19[i] =   gamma_H_0_19    * omega_0_19   * y_ode[i,5];
    H_inc_20_39[i] =  gamma_H_20_39   * omega_20_39  * y_ode[i,12];
    H_inc_40_59[i] =  gamma_H_40_59   * omega_40_59  * y_ode[i,19];
    H_inc_60_79[i] =  gamma_H_60_79   * omega_60_79  * y_ode[i,26];
    H_inc_over80[i] = gamma_H_over80  * omega_over80 * y_ode[i,33];
    
    IC_inc_0_19[i] =   delta_IC * alpha_0_19   * y_ode[i,7];
    IC_inc_20_39[i] =  delta_IC * alpha_20_39  * y_ode[i,14];
    IC_inc_40_59[i] =  delta_IC * alpha_40_59  * y_ode[i,21];
    IC_inc_60_79[i] =  delta_IC * alpha_60_79  * y_ode[i,28];
    IC_inc_over80[i] = delta_IC * alpha_over80 * y_ode[i,35];
    
    
    D_inc_0_19[i]   = gamma_D_0_19  * phi_0_19 *(1-omega_0_19) * y_ode[i,5] + delta_D * psi_0_19 *(1-alpha_0_19) * y_ode[i,7] + mu * y_ode[i,8];
    D_inc_20_39[i]  = gamma_D_20_39  * phi_20_39 *(1-omega_20_39) * y_ode[i,12] + delta_D * psi_20_39  *(1-alpha_20_39) * y_ode[i,14] + mu * y_ode[i,15];
    D_inc_40_59[i]  = gamma_D_40_59  * phi_40_59 *(1-omega_40_59) * y_ode[i,19] + delta_D  * psi_40_59 *(1-alpha_40_59) * y_ode[i,21] + mu * y_ode[i,22];
    D_inc_60_79[i]  = gamma_D_60_79  * phi_60_79 *(1-omega_60_79) * y_ode[i,26] + delta_D  * psi_60_79 *(1-alpha_60_79) * y_ode[i,28] + mu * y_ode[i,29];
    D_inc_over80[i] = gamma_D_over80  * phi_over80 *(1-omega_over80) * y_ode[i,33] + delta_D * psi_over80 *(1-alpha_over80) * y_ode[i,35]  + mu * y_ode[i,36];}
  
  IS_inc_ave_0_19[1] <- (IS_inc_0_19[1] + IS_inc_0_19[2] + IS_inc_0_19[3] + IS_inc_0_19[4])/4
  IS_inc_ave_20_39[1] <- (IS_inc_20_39[1] + IS_inc_20_39[2] + IS_inc_20_39[3] + IS_inc_20_39[4])/4
  IS_inc_ave_40_59[1] <- (IS_inc_40_59[1] + IS_inc_40_59[2] + IS_inc_40_59[3] + IS_inc_40_59[4])/4
  IS_inc_ave_60_79[1] <- (IS_inc_60_79[1] + IS_inc_60_79[2] + IS_inc_60_79[3] + IS_inc_60_79[4])/4
  IS_inc_ave_over80[1] <- (IS_inc_over80[1] + IS_inc_over80[2] + IS_inc_over80[3] + IS_inc_over80[4])/4
  
  IS_inc_ave_0_19[2] <- (IS_inc_0_19[1] + IS_inc_0_19[2] + IS_inc_0_19[3] + IS_inc_0_19[4] + IS_inc_0_19[5])/5
  IS_inc_ave_20_39[2] <- (IS_inc_20_39[1] + IS_inc_20_39[2] + IS_inc_20_39[3] + IS_inc_20_39[4] + IS_inc_20_39[5])/5
  IS_inc_ave_40_59[2] <-(IS_inc_40_59[1] + IS_inc_40_59[2] + IS_inc_40_59[3] + IS_inc_40_59[4] + IS_inc_40_59[5])/5
  IS_inc_ave_60_79[2] <-(IS_inc_60_79[1] + IS_inc_60_79[2] + IS_inc_60_79[3] + IS_inc_60_79[4] + IS_inc_60_79[5])/5
  IS_inc_ave_over80[2] <-(IS_inc_over80[1] + IS_inc_over80[2] + IS_inc_over80[3] + IS_inc_over80[4] + IS_inc_over80[5])/5
  
  IS_inc_ave_0_19[3] <- (IS_inc_0_19[1] + IS_inc_0_19[2] + IS_inc_0_19[3] + IS_inc_0_19[4] + IS_inc_0_19[5] + IS_inc_0_19[6])/6
  IS_inc_ave_20_39[3] <- (IS_inc_20_39[1] + IS_inc_20_39[2] + IS_inc_20_39[3] + IS_inc_20_39[4] + IS_inc_20_39[5] + IS_inc_20_39[6])/6
  IS_inc_ave_40_59[3] <-(IS_inc_40_59[1] + IS_inc_40_59[2] + IS_inc_40_59[3] + IS_inc_40_59[4] + IS_inc_40_59[5] + IS_inc_40_59[6])/6
  IS_inc_ave_60_79[3] <-(IS_inc_60_79[1] + IS_inc_60_79[2] + IS_inc_60_79[3] + IS_inc_60_79[4] + IS_inc_60_79[5] + IS_inc_60_79[6])/6
  IS_inc_ave_over80[3] <-(IS_inc_over80[1] + IS_inc_over80[2] + IS_inc_over80[3] + IS_inc_over80[4] + IS_inc_over80[5] + IS_inc_over80[6])/6
  
  H_inc_ave_0_19[1] <- (H_inc_0_19[1] + H_inc_0_19[2] + H_inc_0_19[3] + H_inc_0_19[4])/4
  H_inc_ave_20_39[1] <- (H_inc_20_39[1] + H_inc_20_39[2] + H_inc_20_39[3] + H_inc_20_39[4])/4
  H_inc_ave_40_59[1] <- (H_inc_40_59[1] + H_inc_40_59[2] + H_inc_40_59[3] + H_inc_40_59[4])/4
  H_inc_ave_60_79[1] <- (H_inc_60_79[1] + H_inc_60_79[2] + H_inc_60_79[3] + H_inc_60_79[4])/4
  H_inc_ave_over80[1] <- (H_inc_over80[1] + H_inc_over80[2] + H_inc_over80[3] + H_inc_over80[4])/4
  
  H_inc_ave_0_19[2] <- (H_inc_0_19[1] + H_inc_0_19[2] + H_inc_0_19[3] + H_inc_0_19[4] + H_inc_0_19[5])/5
  H_inc_ave_20_39[2] <- (H_inc_20_39[1] + H_inc_20_39[2] + H_inc_20_39[3] + H_inc_20_39[4] + H_inc_20_39[5])/5
  H_inc_ave_40_59[2] <-(H_inc_40_59[1] + H_inc_40_59[2] + H_inc_40_59[3] + H_inc_40_59[4] + H_inc_40_59[5])/5
  H_inc_ave_60_79[2] <-(H_inc_60_79[1] + H_inc_60_79[2] + H_inc_60_79[3] + H_inc_60_79[4] + H_inc_60_79[5])/5
  H_inc_ave_over80[2] <-(H_inc_over80[1] + H_inc_over80[2] + H_inc_over80[3] + H_inc_over80[4] + H_inc_over80[5])/5
  
  H_inc_ave_0_19[3] <- (H_inc_0_19[1] + H_inc_0_19[2] + H_inc_0_19[3] + H_inc_0_19[4] + H_inc_0_19[5] + H_inc_0_19[6])/6
  H_inc_ave_20_39[3] <- (H_inc_20_39[1] + H_inc_20_39[2] + H_inc_20_39[3] + H_inc_20_39[4] + H_inc_20_39[5] + H_inc_20_39[6])/6
  H_inc_ave_40_59[3] <-(H_inc_40_59[1] + H_inc_40_59[2] + H_inc_40_59[3] + H_inc_40_59[4] + H_inc_40_59[5] + H_inc_40_59[6])/6
  H_inc_ave_60_79[3] <-(H_inc_60_79[1] + H_inc_60_79[2] + H_inc_60_79[3] + H_inc_60_79[4] + H_inc_60_79[5] + H_inc_60_79[6])/6
  H_inc_ave_over80[3] <-(H_inc_over80[1] + H_inc_over80[2] + H_inc_over80[3] + H_inc_over80[4] + H_inc_over80[5] + H_inc_over80[6])/6
  
  IC_inc_ave_0_19[1] <- (IC_inc_0_19[1] + IC_inc_0_19[2] + IC_inc_0_19[3] + IC_inc_0_19[4])/4
  IC_inc_ave_20_39[1] <- (IC_inc_20_39[1] + IC_inc_20_39[2] + IC_inc_20_39[3] + IC_inc_20_39[4])/4
  IC_inc_ave_40_59[1] <- (IC_inc_40_59[1] + IC_inc_40_59[2] + IC_inc_40_59[3] + IC_inc_40_59[4])/4
  IC_inc_ave_60_79[1] <- (IC_inc_60_79[1] + IC_inc_60_79[2] + IC_inc_60_79[3] + IC_inc_60_79[4])/4
  IC_inc_ave_over80[1] <- (IC_inc_over80[1] + IC_inc_over80[2] + IC_inc_over80[3] + IC_inc_over80[4])/4
  
  IC_inc_ave_0_19[2] <- (IC_inc_0_19[1] + IC_inc_0_19[2] + IC_inc_0_19[3] + IC_inc_0_19[4] + IC_inc_0_19[5])/5
  IC_inc_ave_20_39[2] <- (IC_inc_20_39[1] + IC_inc_20_39[2] + IC_inc_20_39[3] + IC_inc_20_39[4] + IC_inc_20_39[5])/5
  IC_inc_ave_40_59[2] <-(IC_inc_40_59[1] + IC_inc_40_59[2] + IC_inc_40_59[3] + IC_inc_40_59[4] + IC_inc_40_59[5])/5
  IC_inc_ave_60_79[2] <-(IC_inc_60_79[1] + IC_inc_60_79[2] + IC_inc_60_79[3] + IC_inc_60_79[4] + IC_inc_60_79[5])/5
  IC_inc_ave_over80[2] <-(IC_inc_over80[1] + IC_inc_over80[2] + IC_inc_over80[3] + IC_inc_over80[4] + IC_inc_over80[5])/5
  
  IC_inc_ave_0_19[3] <- (IC_inc_0_19[1] + IC_inc_0_19[2] + IC_inc_0_19[3] + IC_inc_0_19[4] + IC_inc_0_19[5] + IC_inc_0_19[6])/6
  IC_inc_ave_20_39[3] <- (IC_inc_20_39[1] + IC_inc_20_39[2] + IC_inc_20_39[3] + IC_inc_20_39[4] + IC_inc_20_39[5] + IC_inc_20_39[6])/6
  IC_inc_ave_40_59[3] <-(IC_inc_40_59[1] + IC_inc_40_59[2] + IC_inc_40_59[3] + IC_inc_40_59[4] + IC_inc_40_59[5] + IC_inc_40_59[6])/6
  IC_inc_ave_60_79[3] <-(IC_inc_60_79[1] + IC_inc_60_79[2] + IC_inc_60_79[3] + IC_inc_60_79[4] + IC_inc_60_79[5] + IC_inc_60_79[6])/6
  IC_inc_ave_over80[3] <-(IC_inc_over80[1] + IC_inc_over80[2] + IC_inc_over80[3] + IC_inc_over80[4] + IC_inc_over80[5] + IC_inc_over80[6])/6
  
  D_inc_ave_0_19[1] <- (D_inc_0_19[1] + D_inc_0_19[2] + D_inc_0_19[3] + D_inc_0_19[4])/4
  D_inc_ave_20_39[1] <- (D_inc_20_39[1] + D_inc_20_39[2] + D_inc_20_39[3] + D_inc_20_39[4])/4
  D_inc_ave_40_59[1] <- (D_inc_40_59[1] + D_inc_40_59[2] + D_inc_40_59[3] + D_inc_40_59[4])/4
  D_inc_ave_60_79[1] <- (D_inc_60_79[1] + D_inc_60_79[2] + D_inc_60_79[3] + D_inc_60_79[4])/4
  D_inc_ave_over80[1] <- (D_inc_over80[1] + D_inc_over80[2] + D_inc_over80[3] + D_inc_over80[4])/4
  
  D_inc_ave_0_19[2] <- (D_inc_0_19[1] + D_inc_0_19[2] + D_inc_0_19[3] + D_inc_0_19[4] + D_inc_0_19[5])/5
  D_inc_ave_20_39[2] <- (D_inc_20_39[1] + D_inc_20_39[2] + D_inc_20_39[3] + D_inc_20_39[4] + D_inc_20_39[5])/5
  D_inc_ave_40_59[2] <-(D_inc_40_59[1] + D_inc_40_59[2] + D_inc_40_59[3] + D_inc_40_59[4] + D_inc_40_59[5])/5
  D_inc_ave_60_79[2] <-(D_inc_60_79[1] + D_inc_60_79[2] + D_inc_60_79[3] + D_inc_60_79[4] + D_inc_60_79[5])/5
  D_inc_ave_over80[2] <-(D_inc_over80[1] + D_inc_over80[2] + D_inc_over80[3] + D_inc_over80[4] + D_inc_over80[5])/5
  
  D_inc_ave_0_19[3] <- (D_inc_0_19[1] + D_inc_0_19[2] + D_inc_0_19[3] + D_inc_0_19[4] + D_inc_0_19[5] + D_inc_0_19[6])/6
  D_inc_ave_20_39[3] <- (D_inc_20_39[1] + D_inc_20_39[2] + D_inc_20_39[3] + D_inc_20_39[4] + D_inc_20_39[5] + D_inc_20_39[6])/6
  D_inc_ave_40_59[3] <-(D_inc_40_59[1] + D_inc_40_59[2] + D_inc_40_59[3] + D_inc_40_59[4] + D_inc_40_59[5] + D_inc_40_59[6])/6
  D_inc_ave_60_79[3] <-(D_inc_60_79[1] + D_inc_60_79[2] + D_inc_60_79[3] + D_inc_60_79[4] + D_inc_60_79[5] + D_inc_60_79[6])/6
  D_inc_ave_over80[3] <-(D_inc_over80[1] + D_inc_over80[2] + D_inc_over80[3] + D_inc_over80[4] + D_inc_over80[5] + D_inc_over80[6])/6
  
  for (j in 4:(n_sim-3)){
    
    IS_inc_ave_0_19[j] <- (IS_inc_0_19[j-3] + IS_inc_0_19[j-2] + IS_inc_0_19[j-1] + IS_inc_0_19[j] + IS_inc_0_19[j+1] + IS_inc_0_19[j+2] + IS_inc_0_19[j+3])/7
    IS_inc_ave_20_39[j] <- (IS_inc_20_39[j-3] + IS_inc_20_39[j-2] + IS_inc_20_39[j-1] + IS_inc_20_39[j]+ IS_inc_20_39[j+1] + IS_inc_20_39[j+2] + IS_inc_20_39[j+3])/7
    IS_inc_ave_40_59[j] <-(IS_inc_40_59[1] + IS_inc_40_59[j-2] + IS_inc_40_59[j-1] + IS_inc_40_59[j]+ IS_inc_40_59[j+1] + IS_inc_40_59[j+2] + IS_inc_40_59[j+3])/7
    IS_inc_ave_60_79[j] <-(IS_inc_60_79[j-3] + IS_inc_60_79[j-2] + IS_inc_60_79[j-1] + IS_inc_60_79[j]+ IS_inc_60_79[j+1] + IS_inc_60_79[j+2] + IS_inc_60_79[j+3])/7
    IS_inc_ave_over80[j] <-(IS_inc_over80[j-3] + IS_inc_over80[j-2] + IS_inc_over80[j-1] + IS_inc_over80[j]+ IS_inc_over80[j+1] + IS_inc_over80[j+2] + IS_inc_over80[j+3])/7
    
    
    H_inc_ave_0_19[j] <- (H_inc_0_19[j-3] + H_inc_0_19[j-2] + H_inc_0_19[j-1] + H_inc_0_19[j]+ H_inc_0_19[j+1] + H_inc_0_19[j+2] + H_inc_0_19[j+3])/7
    H_inc_ave_20_39[j] <- (H_inc_20_39[j-3] + H_inc_20_39[j-2] + H_inc_20_39[j-1] + H_inc_20_39[j]+ H_inc_20_39[j+1] + H_inc_20_39[j+2] + H_inc_20_39[j+3])/7
    H_inc_ave_40_59[j] <-(H_inc_40_59[1] + H_inc_40_59[j-2] + H_inc_40_59[j-1] + H_inc_40_59[j]+ H_inc_40_59[j+1] + H_inc_40_59[j+2] + H_inc_40_59[j+3])/7
    H_inc_ave_60_79[j] <-(H_inc_60_79[j-3] + H_inc_60_79[j-2] + H_inc_60_79[j-1] + H_inc_60_79[j]+ H_inc_60_79[j+1] + H_inc_60_79[j+2] + H_inc_60_79[j+3])/7
    H_inc_ave_over80[j] <-(H_inc_over80[j-3] + H_inc_over80[j-2] + H_inc_over80[j-1] + H_inc_over80[j]+ H_inc_over80[j+1] + H_inc_over80[j+2] + H_inc_over80[j+3])/7
    
    IC_inc_ave_0_19[j] <- (IC_inc_0_19[j-3] + IC_inc_0_19[j-2] + IC_inc_0_19[j-1] + IC_inc_0_19[j]+ IC_inc_0_19[j+1] + IC_inc_0_19[j+2] + IC_inc_0_19[j+3])/7
    IC_inc_ave_20_39[j] <- (IC_inc_20_39[j-3] + IC_inc_20_39[j-2] + IC_inc_20_39[j-1] + IC_inc_20_39[j]+ IC_inc_20_39[j+1] + IC_inc_20_39[j+2] + IC_inc_20_39[j+3])/7
    IC_inc_ave_40_59[j] <-(IC_inc_40_59[1] + IC_inc_40_59[j-2] + IC_inc_40_59[j-1] + IC_inc_40_59[j]+ IC_inc_40_59[j+1] + IC_inc_40_59[j+2] + IC_inc_40_59[j+3])/7
    IC_inc_ave_60_79[j] <-(IC_inc_60_79[j-3] + IC_inc_60_79[j-2] + IC_inc_60_79[j-1] + IC_inc_60_79[j]+ IC_inc_60_79[j+1] + IC_inc_60_79[j+2] + IC_inc_60_79[j+3])/7
    IC_inc_ave_over80[j] <-(IC_inc_over80[j-3] + IC_inc_over80[j-2] + IC_inc_over80[j-1] + IC_inc_over80[j]+ IC_inc_over80[j+1] + IC_inc_over80[j+2] + IC_inc_over80[j+3])/7
    
    D_inc_ave_0_19[j] <- (D_inc_0_19[j-3] + D_inc_0_19[j-2] + D_inc_0_19[j-1] + D_inc_0_19[j]+ D_inc_0_19[j+1] + D_inc_0_19[j+2] + D_inc_0_19[j+3])/7
    D_inc_ave_20_39[j] <- (D_inc_20_39[j-3] + D_inc_20_39[j-2] + D_inc_20_39[j-1] + D_inc_20_39[j]+ D_inc_20_39[j+1] + D_inc_20_39[j+2] + D_inc_20_39[j+3])/7
    D_inc_ave_40_59[j] <-(D_inc_40_59[1] + D_inc_40_59[j-2] + D_inc_40_59[j-1] + D_inc_40_59[j]+ D_inc_40_59[j+1] + D_inc_40_59[j+2] + D_inc_40_59[j+3])/7
    D_inc_ave_60_79[j] <-(D_inc_60_79[j-3] + D_inc_60_79[j-2] + D_inc_60_79[j-1] + D_inc_60_79[j]+ D_inc_60_79[j+1] + D_inc_60_79[j+2] + D_inc_60_79[j+3])/7
    D_inc_ave_over80[j] <-(D_inc_over80[j-3] + D_inc_over80[j-2] + D_inc_over80[j-1] + D_inc_over80[j]+ D_inc_over80[j+1] + D_inc_over80[j+2] + D_inc_over80[j+3])/7
    
  } 
  IS_inc_ave_0_19[n_sim-2] <- (IS_inc_0_19[n_sim] + IS_inc_0_19[n_sim-1] + IS_inc_0_19[n_sim-2] + IS_inc_0_19[n_sim-3] + IS_inc_0_19[n_sim-4] + IS_inc_0_19[n_sim-5])/6
  IS_inc_ave_20_39[n_sim-2] <- (IS_inc_20_39[n_sim] + IS_inc_20_39[n_sim-1] + IS_inc_20_39[n_sim-2] + IS_inc_20_39[n_sim-3] + IS_inc_20_39[n_sim-4] + IS_inc_20_39[n_sim-5])/6
  IS_inc_ave_40_59[n_sim-2] <-(IS_inc_40_59[n_sim] + IS_inc_40_59[n_sim-1] + IS_inc_40_59[n_sim-2] + IS_inc_40_59[n_sim-3] + IS_inc_40_59[n_sim-4] + IS_inc_40_59[n_sim-5])/6
  IS_inc_ave_60_79[n_sim-2] <-(IS_inc_60_79[n_sim] + IS_inc_60_79[n_sim-1] + IS_inc_60_79[n_sim-2] + IS_inc_60_79[n_sim-3] + IS_inc_60_79[n_sim-4] + IS_inc_60_79[n_sim-5])/6
  IS_inc_ave_over80[n_sim-2] <-(IS_inc_over80[n_sim] + IS_inc_over80[n_sim-1] + IS_inc_over80[n_sim-2] + IS_inc_over80[n_sim-3] + IS_inc_over80[n_sim-4] + IS_inc_over80[n_sim-5])/6
  
  IS_inc_ave_0_19[n_sim-1] <- (IS_inc_0_19[n_sim] + IS_inc_0_19[n_sim-1] + IS_inc_0_19[n_sim-2] + IS_inc_0_19[n_sim-3] + IS_inc_0_19[n_sim-4])/5
  IS_inc_ave_20_39[n_sim-1] <- (IS_inc_20_39[n_sim] + IS_inc_20_39[n_sim-1] + IS_inc_20_39[n_sim-2] + IS_inc_20_39[n_sim-3] + IS_inc_20_39[n_sim-4])/5
  IS_inc_ave_40_59[n_sim-1] <-(IS_inc_40_59[n_sim] + IS_inc_40_59[n_sim-1] + IS_inc_40_59[n_sim-2] + IS_inc_40_59[n_sim-3] + IS_inc_40_59[n_sim-4])/5
  IS_inc_ave_60_79[n_sim-1] <-(IS_inc_60_79[n_sim] + IS_inc_60_79[n_sim-1] + IS_inc_60_79[n_sim-2] + IS_inc_60_79[n_sim-3] + IS_inc_60_79[n_sim-4])/5
  IS_inc_ave_over80[n_sim-1] <-(IS_inc_over80[n_sim] + IS_inc_over80[n_sim-1] + IS_inc_over80[n_sim-2] + IS_inc_over80[n_sim-3] + IS_inc_over80[n_sim-4])/5
  
  IS_inc_ave_0_19[n_sim] <- (IS_inc_0_19[n_sim] + IS_inc_0_19[n_sim-1] + IS_inc_0_19[n_sim-2] + IS_inc_0_19[n_sim-3])/4
  IS_inc_ave_20_39[n_sim] <- (IS_inc_20_39[n_sim] + IS_inc_20_39[n_sim-1] + IS_inc_20_39[n_sim-2] + IS_inc_20_39[n_sim-3])/4
  IS_inc_ave_40_59[n_sim] <- (IS_inc_40_59[n_sim] + IS_inc_40_59[n_sim-1] + IS_inc_40_59[n_sim-2] + IS_inc_40_59[n_sim-3])/4
  IS_inc_ave_60_79[n_sim] <- (IS_inc_60_79[n_sim] + IS_inc_60_79[n_sim-1] + IS_inc_60_79[n_sim-2] + IS_inc_60_79[n_sim-3])/4
  IS_inc_ave_over80[n_sim] <- (IS_inc_over80[n_sim] + IS_inc_over80[n_sim-1] + IS_inc_over80[n_sim-2] + IS_inc_over80[n_sim-3])/4
  
  H_inc_ave_0_19[n_sim-2] <- (H_inc_0_19[n_sim] + H_inc_0_19[n_sim-1] + H_inc_0_19[n_sim-2] + H_inc_0_19[n_sim-3] + H_inc_0_19[n_sim-4] + H_inc_0_19[n_sim-5])/6
  H_inc_ave_20_39[n_sim-2] <- (H_inc_20_39[n_sim] + H_inc_20_39[n_sim-1] + H_inc_20_39[n_sim-2] + H_inc_20_39[n_sim-3] + H_inc_20_39[n_sim-4] + H_inc_20_39[n_sim-5])/6
  H_inc_ave_40_59[n_sim-2] <-(H_inc_40_59[n_sim] + H_inc_40_59[n_sim-1] + H_inc_40_59[n_sim-2] + H_inc_40_59[n_sim-3] + H_inc_40_59[n_sim-4] + H_inc_40_59[n_sim-5])/6
  H_inc_ave_60_79[n_sim-2] <-(H_inc_60_79[n_sim] + H_inc_60_79[n_sim-1] + H_inc_60_79[n_sim-2] + H_inc_60_79[n_sim-3] + H_inc_60_79[n_sim-4] + H_inc_60_79[n_sim-5])/6
  H_inc_ave_over80[n_sim-2] <-(H_inc_over80[n_sim] + H_inc_over80[n_sim-1] + H_inc_over80[n_sim-2] + H_inc_over80[n_sim-3] + H_inc_over80[n_sim-4] + H_inc_over80[n_sim-5])/6
  
  H_inc_ave_0_19[n_sim-1] <- (H_inc_0_19[n_sim] + H_inc_0_19[n_sim-1] + H_inc_0_19[n_sim-2] + H_inc_0_19[n_sim-3] + H_inc_0_19[n_sim-4])/5
  H_inc_ave_20_39[n_sim-1] <- (H_inc_20_39[n_sim] + H_inc_20_39[n_sim-1] + H_inc_20_39[n_sim-2] + H_inc_20_39[n_sim-3] + H_inc_20_39[n_sim-4])/5
  H_inc_ave_40_59[n_sim-1] <-(H_inc_40_59[n_sim] + H_inc_40_59[n_sim-1] + H_inc_40_59[n_sim-2] + H_inc_40_59[n_sim-3] + H_inc_40_59[n_sim-4])/5
  H_inc_ave_60_79[n_sim-1] <-(H_inc_60_79[n_sim] + H_inc_60_79[n_sim-1] + H_inc_60_79[n_sim-2] + H_inc_60_79[n_sim-3] + H_inc_60_79[n_sim-4])/5
  H_inc_ave_over80[n_sim-1] <-(H_inc_over80[n_sim] + H_inc_over80[n_sim-1] + H_inc_over80[n_sim-2] + H_inc_over80[n_sim-3] + H_inc_over80[n_sim-4])/5
  
  H_inc_ave_0_19[n_sim] <- (H_inc_0_19[n_sim] + H_inc_0_19[n_sim-1] + H_inc_0_19[n_sim-2] + H_inc_0_19[n_sim-3])/4
  H_inc_ave_20_39[n_sim] <- (H_inc_20_39[n_sim] + H_inc_20_39[n_sim-1] + H_inc_20_39[n_sim-2] + H_inc_20_39[n_sim-3])/4
  H_inc_ave_40_59[n_sim] <- (H_inc_40_59[n_sim] + H_inc_40_59[n_sim-1] + H_inc_40_59[n_sim-2] + H_inc_40_59[n_sim-3])/4
  H_inc_ave_60_79[n_sim] <- (H_inc_60_79[n_sim] + H_inc_60_79[n_sim-1] + H_inc_60_79[n_sim-2] + H_inc_60_79[n_sim-3])/4
  H_inc_ave_over80[n_sim] <- (H_inc_over80[n_sim] + H_inc_over80[n_sim-1] + H_inc_over80[n_sim-2] + H_inc_over80[n_sim-3])/4
  
  IC_inc_ave_0_19[n_sim-2] <- (IC_inc_0_19[n_sim] + IC_inc_0_19[n_sim-1] + IC_inc_0_19[n_sim-2] + IC_inc_0_19[n_sim-3] + IC_inc_0_19[n_sim-4] + IC_inc_0_19[n_sim-5])/6
  IC_inc_ave_20_39[n_sim-2] <- (IC_inc_20_39[n_sim] + IC_inc_20_39[n_sim-1] + IC_inc_20_39[n_sim-2] + IC_inc_20_39[n_sim-3] + IC_inc_20_39[n_sim-4] + IC_inc_20_39[n_sim-5])/6
  IC_inc_ave_40_59[n_sim-2] <-(IC_inc_40_59[n_sim] + IC_inc_40_59[n_sim-1] + IC_inc_40_59[n_sim-2] + IC_inc_40_59[n_sim-3] + IC_inc_40_59[n_sim-4] + IC_inc_40_59[n_sim-5])/6
  IC_inc_ave_60_79[n_sim-2] <-(IC_inc_60_79[n_sim] + IC_inc_60_79[n_sim-1] + IC_inc_60_79[n_sim-2] + IC_inc_60_79[n_sim-3] + IC_inc_60_79[n_sim-4] + IC_inc_60_79[n_sim-5])/6
  IC_inc_ave_over80[n_sim-2] <-(IC_inc_over80[n_sim] + IC_inc_over80[n_sim-1] + IC_inc_over80[n_sim-2] + IC_inc_over80[n_sim-3] + IC_inc_over80[n_sim-4] + IC_inc_over80[n_sim-5])/6
  
  IC_inc_ave_0_19[n_sim-1] <- (IC_inc_0_19[n_sim] + IC_inc_0_19[n_sim-1] + IC_inc_0_19[n_sim-2] + IC_inc_0_19[n_sim-3] + IC_inc_0_19[n_sim-4])/5
  IC_inc_ave_20_39[n_sim-1] <- (IC_inc_20_39[n_sim] + IC_inc_20_39[n_sim-1] + IC_inc_20_39[n_sim-2] + IC_inc_20_39[n_sim-3] + IC_inc_20_39[n_sim-4])/5
  IC_inc_ave_40_59[n_sim-1] <-(IC_inc_40_59[n_sim] + IC_inc_40_59[n_sim-1] + IC_inc_40_59[n_sim-2] + IC_inc_40_59[n_sim-3] + IC_inc_40_59[n_sim-4])/5
  IC_inc_ave_60_79[n_sim-1] <-(IC_inc_60_79[n_sim] + IC_inc_60_79[n_sim-1] + IC_inc_60_79[n_sim-2] + IC_inc_60_79[n_sim-3] + IC_inc_60_79[n_sim-4])/5
  IC_inc_ave_over80[n_sim-1] <-(IC_inc_over80[n_sim] + IC_inc_over80[n_sim-1] + IC_inc_over80[n_sim-2] + IC_inc_over80[n_sim-3] + IC_inc_over80[n_sim-4])/5
  
  IC_inc_ave_0_19[n_sim] <- (IC_inc_0_19[n_sim] + IC_inc_0_19[n_sim-1] + IC_inc_0_19[n_sim-2] + IC_inc_0_19[n_sim-3])/4
  IC_inc_ave_20_39[n_sim] <- (IC_inc_20_39[n_sim] + IC_inc_20_39[n_sim-1] + IC_inc_20_39[n_sim-2] + IC_inc_20_39[n_sim-3])/4
  IC_inc_ave_40_59[n_sim] <- (IC_inc_40_59[n_sim] + IC_inc_40_59[n_sim-1] + IC_inc_40_59[n_sim-2] + IC_inc_40_59[n_sim-3])/4
  IC_inc_ave_60_79[n_sim] <- (IC_inc_60_79[n_sim] + IC_inc_60_79[n_sim-1] + IC_inc_60_79[n_sim-2] + IC_inc_60_79[n_sim-3])/4
  IC_inc_ave_over80[n_sim] <- (IC_inc_over80[n_sim] + IC_inc_over80[n_sim-1] + IC_inc_over80[n_sim-2] + IC_inc_over80[n_sim-3])/4 
  
  D_inc_ave_0_19[n_sim-2] <- (D_inc_0_19[n_sim] + D_inc_0_19[n_sim-1] + D_inc_0_19[n_sim-2] + D_inc_0_19[n_sim-3] + D_inc_0_19[n_sim-4] + D_inc_0_19[n_sim-5])/6
  D_inc_ave_20_39[n_sim-2] <- (D_inc_20_39[n_sim] + D_inc_20_39[n_sim-1] + D_inc_20_39[n_sim-2] + D_inc_20_39[n_sim-3] + D_inc_20_39[n_sim-4] + D_inc_20_39[n_sim-5])/6
  D_inc_ave_40_59[n_sim-2] <-(D_inc_40_59[n_sim] + D_inc_40_59[n_sim-1] + D_inc_40_59[n_sim-2] + D_inc_40_59[n_sim-3] + D_inc_40_59[n_sim-4] + D_inc_40_59[n_sim-5])/6
  D_inc_ave_60_79[n_sim-2] <-(D_inc_60_79[n_sim] + D_inc_60_79[n_sim-1] + D_inc_60_79[n_sim-2] + D_inc_60_79[n_sim-3] + D_inc_60_79[n_sim-4] + D_inc_60_79[n_sim-5])/6
  D_inc_ave_over80[n_sim-2] <-(D_inc_over80[n_sim] + D_inc_over80[n_sim-1] + D_inc_over80[n_sim-2] + D_inc_over80[n_sim-3] + D_inc_over80[n_sim-4] + D_inc_over80[n_sim-5])/6
  
  D_inc_ave_0_19[n_sim-1] <- (D_inc_0_19[n_sim] + D_inc_0_19[n_sim-1] + D_inc_0_19[n_sim-2] + D_inc_0_19[n_sim-3] + D_inc_0_19[n_sim-4])/5
  D_inc_ave_20_39[n_sim-1] <- (D_inc_20_39[n_sim] + D_inc_20_39[n_sim-1] + D_inc_20_39[n_sim-2] + D_inc_20_39[n_sim-3] + D_inc_20_39[n_sim-4])/5
  D_inc_ave_40_59[n_sim-1] <-(D_inc_40_59[n_sim] + D_inc_40_59[n_sim-1] + D_inc_40_59[n_sim-2] + D_inc_40_59[n_sim-3] + D_inc_40_59[n_sim-4])/5
  D_inc_ave_60_79[n_sim-1] <-(D_inc_60_79[n_sim] + D_inc_60_79[n_sim-1] + D_inc_60_79[n_sim-2] + D_inc_60_79[n_sim-3] + D_inc_60_79[n_sim-4])/5
  D_inc_ave_over80[n_sim-1] <-(D_inc_over80[n_sim] + D_inc_over80[n_sim-1] + D_inc_over80[n_sim-2] + D_inc_over80[n_sim-3] + D_inc_over80[n_sim-4])/5
  
  D_inc_ave_0_19[n_sim] <- (D_inc_0_19[n_sim] + D_inc_0_19[n_sim-1] + D_inc_0_19[n_sim-2] + D_inc_0_19[n_sim-3])/4
  D_inc_ave_20_39[n_sim] <- (D_inc_20_39[n_sim] + D_inc_20_39[n_sim-1] + D_inc_20_39[n_sim-2] + D_inc_20_39[n_sim-3])/4
  D_inc_ave_40_59[n_sim] <- (D_inc_40_59[n_sim] + D_inc_40_59[n_sim-1] + D_inc_40_59[n_sim-2] + D_inc_40_59[n_sim-3])/4
  D_inc_ave_60_79[n_sim] <- (D_inc_60_79[n_sim] + D_inc_60_79[n_sim-1] + D_inc_60_79[n_sim-2] + D_inc_60_79[n_sim-3])/4
  D_inc_ave_over80[n_sim] <- (D_inc_over80[n_sim] + D_inc_over80[n_sim-1] + D_inc_over80[n_sim-2] + D_inc_over80[n_sim-3])/4
  
  IS_acc_0_19[1]   =  IS_inc_ave_0_19[1];
  IS_acc_20_39[1]   =  IS_inc_ave_20_39[1];
  IS_acc_40_59[1]   =  IS_inc_ave_40_59[1];
  IS_acc_60_79[1]   =  IS_inc_ave_60_79[1];
  IS_acc_over80[1]   =  IS_inc_ave_over80[1];
  
  H_acc_0_19[1]   =  H_inc_ave_0_19[1];
  H_acc_20_39[1]   =  H_inc_ave_20_39[1];
  H_acc_40_59[1]   =  H_inc_ave_40_59[1];
  H_acc_60_79[1]   =  H_inc_ave_60_79[1];
  H_acc_over80[1]   =  H_inc_ave_over80[1];
  
  IC_acc_0_19[1]   =  IC_inc_ave_0_19[1];
  IC_acc_20_39[1]   =  IC_inc_ave_20_39[1];
  IC_acc_40_59[1]   =  IC_inc_ave_40_59[1];
  IC_acc_60_79[1]   =  IC_inc_ave_60_79[1];
  IC_acc_over80[1]   =  IC_inc_ave_over80[1];
  
  D_acc_0_19[1]   =  D_inc_ave_0_19[1];
  D_acc_20_39[1]   =  D_inc_ave_20_39[1];
  D_acc_40_59[1]   =  D_inc_ave_40_59[1];
  D_acc_60_79[1]   =  D_inc_ave_60_79[1];
  D_acc_over80[1]   =  D_inc_ave_over80[1];
  
  for (k in 2:(n_sim)){
  IS_acc_0_19[k]   = IS_acc_0_19[k-1] + IS_inc_ave_0_19[k];
  IS_acc_20_39[k]   = IS_acc_20_39[k-1] + IS_inc_ave_20_39[k];
  IS_acc_40_59[k]   = IS_acc_40_59[k-1] + IS_inc_ave_40_59[k];
  IS_acc_60_79[k]   = IS_acc_60_79[k-1] + IS_inc_ave_60_79[k];
  IS_acc_over80[k]   = IS_acc_over80[k-1] + IS_inc_ave_over80[k];
  
  H_acc_0_19[k]   = H_acc_0_19[k-1] + H_inc_ave_0_19[k];
  H_acc_20_39[k]   = H_acc_20_39[k-1] + H_inc_ave_20_39[k];
  H_acc_40_59[k]   = H_acc_40_59[k-1] + H_inc_ave_40_59[k];
  H_acc_60_79[k]   = H_acc_60_79[k-1] + H_inc_ave_60_79[k];
  H_acc_over80[k]   = H_acc_over80[k-1] + H_inc_ave_over80[k];
  
  IC_acc_0_19[k]   = IC_acc_0_19[k-1] + IC_inc_ave_0_19[k];
  IC_acc_20_39[k]   = IC_acc_20_39[k-1] + IC_inc_ave_20_39[k];
  IC_acc_40_59[k]   = IC_acc_40_59[k-1] + IC_inc_ave_40_59[k];
  IC_acc_60_79[k]   = IC_acc_60_79[k-1] + IC_inc_ave_60_79[k];
  IC_acc_over80[k]   = IC_acc_over80[k-1] + IC_inc_ave_over80[k];
  
  D_acc_0_19[k]   = D_acc_0_19[k-1] + D_inc_ave_0_19[k];
  D_acc_20_39[k]   = D_acc_20_39[k-1] + D_inc_ave_20_39[k];
  D_acc_40_59[k]   = D_acc_40_59[k-1] + D_inc_ave_40_59[k];
  D_acc_60_79[k]   = D_acc_60_79[k-1] + D_inc_ave_60_79[k];
  D_acc_over80[k]   = D_acc_over80[k-1] + D_inc_ave_over80[k];
  
  }
  
  IS_inc_traj_0_19 <- cbind(IS_inc_traj_0_19 , IS_inc_ave_0_19)
  IS_inc_traj_20_39 <- cbind(IS_inc_traj_20_39 , IS_inc_ave_20_39)
  IS_inc_traj_40_59 <- cbind(IS_inc_traj_40_59 , IS_inc_ave_40_59)
  IS_inc_traj_60_79 <- cbind(IS_inc_traj_60_79 , IS_inc_ave_60_79)
  IS_inc_traj_over80 <- cbind(IS_inc_traj_over80 , IS_inc_ave_over80)
  
  H_inc_traj_0_19 <- cbind(H_inc_traj_0_19 , H_inc_ave_0_19)
  H_inc_traj_20_39 <- cbind(H_inc_traj_20_39 , H_inc_ave_20_39)
  H_inc_traj_40_59 <- cbind(H_inc_traj_40_59 , H_inc_ave_40_59)
  H_inc_traj_60_79 <- cbind(H_inc_traj_60_79 , H_inc_ave_60_79)
  H_inc_traj_over80 <- cbind(H_inc_traj_over80 , H_inc_ave_over80)
  
  IC_inc_traj_0_19 <- cbind(IC_inc_traj_0_19 , IC_inc_ave_0_19)
  IC_inc_traj_20_39 <- cbind(IC_inc_traj_20_39 , IC_inc_ave_20_39)
  IC_inc_traj_40_59 <- cbind(IC_inc_traj_40_59 , IC_inc_ave_40_59)
  IC_inc_traj_60_79 <- cbind(IC_inc_traj_60_79 , IC_inc_ave_60_79)
  IC_inc_traj_over80 <- cbind(IC_inc_traj_over80 , IC_inc_ave_over80)
  
  D_inc_traj_0_19 <- cbind(D_inc_traj_0_19 , D_inc_ave_0_19)
  D_inc_traj_20_39 <- cbind(D_inc_traj_20_39 , D_inc_ave_20_39)
  D_inc_traj_40_59 <- cbind(D_inc_traj_40_59 , D_inc_ave_40_59)
  D_inc_traj_60_79 <- cbind(D_inc_traj_60_79 , D_inc_ave_60_79)
  D_inc_traj_over80 <- cbind(D_inc_traj_over80 , D_inc_ave_over80)
  
  IS_acc_traj_0_19 <- cbind(IS_acc_traj_0_19 , IS_acc_0_19)
  IS_acc_traj_20_39 <- cbind(IS_acc_traj_20_39 , IS_acc_20_39)
  IS_acc_traj_40_59 <- cbind(IS_acc_traj_40_59 , IS_acc_40_59)
  IS_acc_traj_60_79 <- cbind(IS_acc_traj_60_79 , IS_acc_60_79)
  IS_acc_traj_over80 <- cbind(IS_acc_traj_over80 , IS_acc_over80)
  
  H_acc_traj_0_19 <- cbind(H_acc_traj_0_19 , H_acc_0_19)
  H_acc_traj_20_39 <- cbind(H_acc_traj_20_39 , H_acc_20_39)
  H_acc_traj_40_59 <- cbind(H_acc_traj_40_59 , H_acc_40_59)
  H_acc_traj_60_79 <- cbind(H_acc_traj_60_79 , H_acc_60_79)
  H_acc_traj_over80 <- cbind(H_acc_traj_over80 , H_acc_over80)
  
  IC_acc_traj_0_19 <- cbind(IC_acc_traj_0_19 , IC_acc_0_19)
  IC_acc_traj_20_39 <- cbind(IC_acc_traj_20_39 , IC_acc_20_39)
  IC_acc_traj_40_59 <- cbind(IC_acc_traj_40_59 , IC_acc_40_59)
  IC_acc_traj_60_79 <- cbind(IC_acc_traj_60_79 , IC_acc_60_79)
  IC_acc_traj_over80 <- cbind(IC_acc_traj_over80 , IC_acc_over80)
  
  D_acc_traj_0_19 <- cbind(D_acc_traj_0_19 , D_acc_0_19)
  D_acc_traj_20_39 <- cbind(D_acc_traj_20_39 , D_acc_20_39)
  D_acc_traj_40_59 <- cbind(D_acc_traj_40_59 , D_acc_40_59)
  D_acc_traj_60_79 <- cbind(D_acc_traj_60_79 , D_acc_60_79)
  D_acc_traj_over80 <- cbind(D_acc_traj_over80 , D_acc_over80)
  
  S_traj_0_19 <- cbind(S_traj_0_19, y_ode[,2])
  S_traj_20_39 <- cbind(S_traj_20_39, y_ode[,9])
  S_traj_40_59 <- cbind(S_traj_40_59, y_ode[,16])
  S_traj_60_79 <- cbind(S_traj_60_79, y_ode[,23])
  S_traj_over80 <- cbind(S_traj_over80, y_ode[,30])
  
  E_traj_0_19 <- cbind(E_traj_0_19, y_ode[,3])
  E_traj_20_39 <- cbind(E_traj_20_39, y_ode[,10])
  E_traj_40_59 <- cbind(E_traj_40_59, y_ode[,17])
  E_traj_60_79 <- cbind(E_traj_60_79, y_ode[,24])
  E_traj_over80 <- cbind(E_traj_over80, y_ode[,31])
  
  P_traj_0_19 <- cbind(P_traj_0_19, y_ode[,4])
  P_traj_20_39 <- cbind(P_traj_20_39, y_ode[,11])
  P_traj_40_59 <- cbind(P_traj_40_59, y_ode[,18])
  P_traj_60_79 <- cbind(P_traj_60_79, y_ode[,25])
  P_traj_over80 <- cbind(P_traj_over80, y_ode[,32])
  
  IS_traj_0_19 <- cbind(IS_traj_0_19, y_ode[,5])
  IS_traj_20_39 <- cbind(IS_traj_20_39, y_ode[,12])
  IS_traj_40_59 <- cbind(IS_traj_40_59, y_ode[,19])
  IS_traj_60_79 <- cbind(IS_traj_60_79, y_ode[,26])
  IS_traj_over80 <- cbind(IS_traj_over80, y_ode[,33])
  
  IA_traj_0_19 <- cbind(IA_traj_0_19, y_ode[,6])
  IA_traj_20_39 <- cbind(IA_traj_20_39, y_ode[,13])
  IA_traj_40_59 <- cbind(IA_traj_40_59, y_ode[,20])
  IA_traj_60_79 <- cbind(IA_traj_60_79, y_ode[,27])
  IA_traj_over80 <- cbind(IA_traj_over80, y_ode[,34])
  
  H_traj_0_19 <- cbind(H_traj_0_19, y_ode[,7])
  H_traj_20_39 <- cbind(H_traj_20_39, y_ode[,14])
  H_traj_40_59 <- cbind(H_traj_40_59, y_ode[,21])
  H_traj_60_79 <- cbind(H_traj_60_79, y_ode[,28])
  H_traj_over80 <- cbind(H_traj_over80, y_ode[,35])
  
  IC_traj_0_19 <- cbind(IC_traj_0_19, y_ode[,8])
  IC_traj_20_39 <- cbind(IC_traj_20_39, y_ode[,15])
  IC_traj_40_59 <- cbind(IC_traj_40_59, y_ode[,22])
  IC_traj_60_79 <- cbind(IC_traj_60_79, y_ode[,29])
  IC_traj_over80 <- cbind(IC_traj_over80, y_ode[,36])
  
}

S_traj_0_19 <- S_traj_0_19[,-1]
S_traj_20_39 <- S_traj_20_39[,-1]
S_traj_40_59 <- S_traj_40_59[,-1]
S_traj_60_79 <- S_traj_60_79[,-1]
S_traj_over80 <- S_traj_over80[,-1]

P_traj_0_19 <- P_traj_0_19[,-1]
P_traj_20_39 <- P_traj_20_39[,-1]
P_traj_40_59 <- P_traj_40_59[,-1]
P_traj_60_79 <- P_traj_60_79[,-1]
P_traj_over80 <- P_traj_over80[,-1]

E_traj_0_19 <- E_traj_0_19[,-1]
E_traj_20_39 <- E_traj_20_39[,-1]
E_traj_40_59 <- E_traj_40_59[,-1]
E_traj_60_79 <- E_traj_60_79[,-1]
E_traj_over80 <- E_traj_over80[,-1]

IS_traj_0_19 <- IS_traj_0_19[,-1]
IS_traj_20_39 <- IS_traj_20_39[,-1]
IS_traj_40_59 <- IS_traj_40_59[,-1]
IS_traj_60_79 <- IS_traj_60_79[,-1]
IS_traj_over80 <- IS_traj_over80[,-1]

IA_traj_0_19 <- IA_traj_0_19[,-1]
IA_traj_20_39 <- IA_traj_20_39[,-1]
IA_traj_40_59 <- IA_traj_40_59[,-1]
IA_traj_60_79 <- IA_traj_60_79[,-1]
IA_traj_over80 <- IA_traj_over80[,-1]

H_traj_0_19 <- H_traj_0_19[,-1]
H_traj_20_39 <- H_traj_20_39[,-1]
H_traj_40_59 <- H_traj_40_59[,-1]
H_traj_60_79 <- H_traj_60_79[,-1]
H_traj_over80 <- H_traj_over80[,-1]

IC_traj_0_19 <- IC_traj_0_19[,-1]
IC_traj_20_39 <- IC_traj_20_39[,-1]
IC_traj_40_59 <- IC_traj_40_59[,-1]
IC_traj_60_79 <- IC_traj_60_79[,-1]
IC_traj_over80 <- IC_traj_over80[,-1]


IS_inc_traj_0_19 <- IS_inc_traj_0_19[,-1]
IS_inc_traj_20_39 <- IS_inc_traj_20_39[,-1]
IS_inc_traj_40_59 <- IS_inc_traj_40_59[,-1]
IS_inc_traj_60_79 <- IS_inc_traj_60_79[,-1]
IS_inc_traj_over80 <- IS_inc_traj_over80[,-1]

H_inc_traj_0_19 <- H_inc_traj_0_19[,-1]
H_inc_traj_20_39 <- H_inc_traj_20_39[,-1]
H_inc_traj_40_59 <- H_inc_traj_40_59[,-1]
H_inc_traj_60_79 <- H_inc_traj_60_79[,-1]
H_inc_traj_over80 <- H_inc_traj_over80[,-1]

IC_inc_traj_0_19 <- IC_inc_traj_0_19[,-1]
IC_inc_traj_20_39 <- IC_inc_traj_20_39[,-1]
IC_inc_traj_40_59 <- IC_inc_traj_40_59[,-1]
IC_inc_traj_60_79 <- IC_inc_traj_60_79[,-1]
IC_inc_traj_over80 <- IC_inc_traj_over80[,-1]

D_inc_traj_0_19 <- D_inc_traj_0_19[,-1]
D_inc_traj_20_39 <- D_inc_traj_20_39[,-1]
D_inc_traj_40_59 <- D_inc_traj_40_59[,-1]
D_inc_traj_60_79 <- D_inc_traj_60_79[,-1]
D_inc_traj_over80 <- D_inc_traj_over80[,-1]

IS_inc_acc_traj_0_19 <- IS_acc_traj_0_19[,-1]
IS_inc_acc_traj_20_39 <- IS_acc_traj_20_39[,-1]
IS_acc_traj_40_59 <- IS_acc_traj_40_59[,-1]
IS_acc_traj_60_79 <- IS_acc_traj_60_79[,-1]
IS_acc_traj_over80 <- IS_acc_traj_over80[,-1]

H_acc_traj_0_19 <- H_acc_traj_0_19[,-1]
H_acc_traj_20_39 <- H_acc_traj_20_39[,-1]
H_acc_traj_40_59 <- H_acc_traj_40_59[,-1]
H_acc_traj_60_79 <- H_acc_traj_60_79[,-1]
H_acc_traj_over80 <- H_acc_traj_over80[,-1]

IC_acc_traj_0_19 <- IC_acc_traj_0_19[,-1]
IC_acc_traj_20_39 <- IC_acc_traj_20_39[,-1]
IC_acc_traj_40_59 <- IC_acc_traj_40_59[,-1]
IC_acc_traj_60_79 <- IC_acc_traj_60_79[,-1]
IC_acc_traj_over80 <- IC_acc_traj_over80[,-1]

D_acc_traj_0_19 <- D_acc_traj_0_19[,-1]
D_acc_traj_20_39 <- D_acc_traj_20_39[,-1]
D_acc_traj_40_59 <- D_acc_traj_40_59[,-1]
D_acc_traj_60_79 <- D_acc_traj_60_79[,-1]
D_acc_traj_over80 <- D_acc_traj_over80[,-1]

S_q1_0_19 <- rep(0,n_sim)
S_m_0_19 <- rep(0,n_sim)
S_q2_0_19 <- rep(0,n_sim)

S_q1_20_39 <- rep(0,n_sim)
S_m_20_39 <- rep(0,n_sim)
S_q2_20_39 <- rep(0,n_sim)

S_q1_40_59 <- rep(0,n_sim)
S_m_40_59 <- rep(0,n_sim)
S_q2_40_59 <- rep(0,n_sim)

S_q1_60_79 <- rep(0,n_sim)
S_m_60_79 <- rep(0,n_sim)
S_q2_60_79 <- rep(0,n_sim)

S_q1_over80 <- rep(0,n_sim)
S_m_over80 <- rep(0,n_sim)
S_q2_over80 <- rep(0,n_sim)

E_q1_0_19 <- rep(0,n_sim)
E_m_0_19 <- rep(0,n_sim)
E_q2_0_19 <- rep(0,n_sim)

E_q1_20_39 <- rep(0,n_sim)
E_m_20_39 <- rep(0,n_sim)
E_q2_20_39 <- rep(0,n_sim)

E_q1_40_59 <- rep(0,n_sim)
E_m_40_59 <- rep(0,n_sim)
E_q2_40_59 <- rep(0,n_sim)

E_q1_60_79 <- rep(0,n_sim)
E_m_60_79 <- rep(0,n_sim)
E_q2_60_79 <- rep(0,n_sim)

E_q1_over80 <- rep(0,n_sim)
E_m_over80 <- rep(0,n_sim)
E_q2_over80 <- rep(0,n_sim)

P_q1_0_19 <- rep(0,n_sim)
P_m_0_19 <- rep(0,n_sim)
P_q2_0_19 <- rep(0,n_sim)

P_q1_20_39 <- rep(0,n_sim)
P_m_20_39 <- rep(0,n_sim)
P_q2_20_39 <- rep(0,n_sim)

P_q1_40_59 <- rep(0,n_sim)
P_m_40_59 <- rep(0,n_sim)
P_q2_40_59 <- rep(0,n_sim)

P_q1_60_79 <- rep(0,n_sim)
P_m_60_79 <- rep(0,n_sim)
P_q2_60_79 <- rep(0,n_sim)

P_q1_over80 <- rep(0,n_sim)
P_m_over80 <- rep(0,n_sim)
P_q2_over80 <- rep(0,n_sim)

IS_q1_0_19 <- rep(0,n_sim)
IS_m_0_19 <- rep(0,n_sim)
IS_q2_0_19 <- rep(0,n_sim)

IS_q1_20_39 <- rep(0,n_sim)
IS_m_20_39 <- rep(0,n_sim)
IS_q2_20_39 <- rep(0,n_sim)

IS_q1_40_59 <- rep(0,n_sim)
IS_m_40_59 <- rep(0,n_sim)
IS_q2_40_59 <- rep(0,n_sim)

IS_q1_60_79 <- rep(0,n_sim)
IS_m_60_79 <- rep(0,n_sim)
IS_q2_60_79 <- rep(0,n_sim)

IS_q1_over80 <- rep(0,n_sim)
IS_m_over80 <- rep(0,n_sim)
IS_q2_over80 <- rep(0,n_sim)

IA_q1_0_19 <- rep(0,n_sim)
IA_m_0_19 <- rep(0,n_sim)
IA_q2_0_19 <- rep(0,n_sim)

IA_q1_20_39 <- rep(0,n_sim)
IA_m_20_39 <- rep(0,n_sim)
IA_q2_20_39 <- rep(0,n_sim)

IA_q1_40_59 <- rep(0,n_sim)
IA_m_40_59 <- rep(0,n_sim)
IA_q2_40_59 <- rep(0,n_sim)

IA_q1_60_79 <- rep(0,n_sim)
IA_m_60_79 <- rep(0,n_sim)
IA_q2_60_79 <- rep(0,n_sim)

IA_q1_over80 <- rep(0,n_sim)
IA_m_over80 <- rep(0,n_sim)
IA_q2_over80 <- rep(0,n_sim)

H_q1_0_19 <- rep(0,n_sim)
H_m_0_19 <- rep(0,n_sim)
H_q2_0_19 <- rep(0,n_sim)

H_q1_20_39 <- rep(0,n_sim)
H_m_20_39 <- rep(0,n_sim)
H_q2_20_39 <- rep(0,n_sim)

H_q1_40_59 <- rep(0,n_sim)
H_m_40_59 <- rep(0,n_sim)
H_q2_40_59 <- rep(0,n_sim)

H_q1_60_79 <- rep(0,n_sim)
H_m_60_79 <- rep(0,n_sim)
H_q2_60_79 <- rep(0,n_sim)

H_q1_over80 <- rep(0,n_sim)
H_m_over80 <- rep(0,n_sim)
H_q2_over80 <- rep(0,n_sim)

IC_q1_0_19 <- rep(0,n_sim)
IC_m_0_19 <- rep(0,n_sim)
IC_q2_0_19 <- rep(0,n_sim)

IC_q1_20_39 <- rep(0,n_sim)
IC_m_20_39 <- rep(0,n_sim)
IC_q2_20_39 <- rep(0,n_sim)

IC_q1_40_59 <- rep(0,n_sim)
IC_m_40_59 <- rep(0,n_sim)
IC_q2_40_59 <- rep(0,n_sim)

IC_q1_60_79 <- rep(0,n_sim)
IC_m_60_79 <- rep(0,n_sim)
IC_q2_60_79 <- rep(0,n_sim)

IC_q1_over80 <- rep(0,n_sim)
IC_m_over80 <- rep(0,n_sim)
IC_q2_over80 <- rep(0,n_sim)


IS_q1_inc_0_19 <- rep(0,n_sim)
IS_m_inc_0_19 <- rep(0,n_sim)
IS_q2_inc_0_19 <- rep(0,n_sim)

IS_q1_inc_20_39 <- rep(0,n_sim)
IS_m_inc_20_39 <- rep(0,n_sim)
IS_q2_inc_20_39 <- rep(0,n_sim)

IS_q1_inc_40_59 <- rep(0,n_sim)
IS_m_inc_40_59 <- rep(0,n_sim)
IS_q2_inc_40_59 <- rep(0,n_sim)

IS_q1_inc_60_79 <- rep(0,n_sim)
IS_m_inc_60_79 <- rep(0,n_sim)
IS_q2_inc_60_79 <- rep(0,n_sim)

IS_q1_inc_over80 <- rep(0,n_sim)
IS_m_inc_over80 <- rep(0,n_sim)
IS_q2_inc_over80 <- rep(0,n_sim)

H_q1_inc_0_19 <- rep(0,n_sim)
H_m_inc_0_19 <- rep(0,n_sim)
H_q2_inc_0_19 <- rep(0,n_sim)

H_q1_inc_20_39 <- rep(0,n_sim)
H_m_inc_20_39 <- rep(0,n_sim)
H_q2_inc_20_39 <- rep(0,n_sim)

H_q1_inc_40_59 <- rep(0,n_sim)
H_m_inc_40_59 <- rep(0,n_sim)
H_q2_inc_40_59 <- rep(0,n_sim)

H_q1_inc_60_79 <- rep(0,n_sim)
H_m_inc_60_79 <- rep(0,n_sim)
H_q2_inc_60_79 <- rep(0,n_sim)

H_q1_inc_over80 <- rep(0,n_sim)
H_m_inc_over80 <- rep(0,n_sim)
H_q2_inc_over80 <- rep(0,n_sim)

IC_q1_inc_0_19 <- rep(0,n_sim)
IC_m_inc_0_19 <- rep(0,n_sim)
IC_q2_inc_0_19 <- rep(0,n_sim)

IC_q1_inc_20_39 <- rep(0,n_sim)
IC_m_inc_20_39 <- rep(0,n_sim)
IC_q2_inc_20_39 <- rep(0,n_sim)

IC_q1_inc_40_59 <- rep(0,n_sim)
IC_m_inc_40_59 <- rep(0,n_sim)
IC_q2_inc_40_59 <- rep(0,n_sim)

IC_q1_inc_60_79 <- rep(0,n_sim)
IC_m_inc_60_79 <- rep(0,n_sim)
IC_q2_inc_60_79 <- rep(0,n_sim)

IC_q1_inc_over80 <- rep(0,n_sim)
IC_m_inc_over80 <- rep(0,n_sim)
IC_q2_inc_over80 <- rep(0,n_sim)

D_q1_inc_0_19 <- rep(0,n_sim)
D_m_inc_0_19 <- rep(0,n_sim)
D_q2_inc_0_19 <- rep(0,n_sim)

D_q1_inc_20_39 <- rep(0,n_sim)
D_m_inc_20_39 <- rep(0,n_sim)
D_q2_inc_20_39 <- rep(0,n_sim)

D_q1_inc_40_59 <- rep(0,n_sim)
D_m_inc_40_59 <- rep(0,n_sim)
D_q2_inc_40_59 <- rep(0,n_sim)

D_q1_inc_60_79 <- rep(0,n_sim)
D_m_inc_60_79 <- rep(0,n_sim)
D_q2_inc_60_79 <- rep(0,n_sim)

D_q1_inc_over80 <- rep(0,n_sim)
D_m_inc_over80 <- rep(0,n_sim)
D_q2_inc_over80 <- rep(0,n_sim)

IS_q1_acc_0_19 <- rep(0,n_sim)
IS_m_acc_0_19 <- rep(0,n_sim)
IS_q2_acc_0_19 <- rep(0,n_sim)

IS_q1_acc_20_39 <- rep(0,n_sim)
IS_m_acc_20_39 <- rep(0,n_sim)
IS_q2_acc_20_39 <- rep(0,n_sim)

IS_q1_acc_40_59 <- rep(0,n_sim)
IS_m_acc_40_59 <- rep(0,n_sim)
IS_q2_acc_40_59 <- rep(0,n_sim)

IS_q1_acc_60_79 <- rep(0,n_sim)
IS_m_acc_60_79 <- rep(0,n_sim)
IS_q2_acc_60_79 <- rep(0,n_sim)

IS_q1_acc_over80 <- rep(0,n_sim)
IS_m_acc_over80 <- rep(0,n_sim)
IS_q2_acc_over80 <- rep(0,n_sim)

H_q1_acc_0_19 <- rep(0,n_sim)
H_m_acc_0_19 <- rep(0,n_sim)
H_q2_acc_0_19 <- rep(0,n_sim)

H_q1_acc_20_39 <- rep(0,n_sim)
H_m_acc_20_39 <- rep(0,n_sim)
H_q2_acc_20_39 <- rep(0,n_sim)

H_q1_acc_40_59 <- rep(0,n_sim)
H_m_acc_40_59 <- rep(0,n_sim)
H_q2_acc_40_59 <- rep(0,n_sim)

H_q1_acc_60_79 <- rep(0,n_sim)
H_m_acc_60_79 <- rep(0,n_sim)
H_q2_acc_60_79 <- rep(0,n_sim)

H_q1_acc_over80 <- rep(0,n_sim)
H_m_acc_over80 <- rep(0,n_sim)
H_q2_acc_over80 <- rep(0,n_sim)

IC_q1_acc_0_19 <- rep(0,n_sim)
IC_m_acc_0_19 <- rep(0,n_sim)
IC_q2_acc_0_19 <- rep(0,n_sim)

IC_q1_acc_20_39 <- rep(0,n_sim)
IC_m_acc_20_39 <- rep(0,n_sim)
IC_q2_acc_20_39 <- rep(0,n_sim)

IC_q1_acc_40_59 <- rep(0,n_sim)
IC_m_acc_40_59 <- rep(0,n_sim)
IC_q2_acc_40_59 <- rep(0,n_sim)

IC_q1_acc_60_79 <- rep(0,n_sim)
IC_m_acc_60_79 <- rep(0,n_sim)
IC_q2_acc_60_79 <- rep(0,n_sim)

IC_q1_acc_over80 <- rep(0,n_sim)
IC_m_acc_over80 <- rep(0,n_sim)
IC_q2_acc_over80 <- rep(0,n_sim)

D_q1_acc_0_19 <- rep(0,n_sim)
D_m_acc_0_19 <- rep(0,n_sim)
D_q2_acc_0_19 <- rep(0,n_sim)

D_q1_acc_20_39 <- rep(0,n_sim)
D_m_acc_20_39 <- rep(0,n_sim)
D_q2_acc_20_39 <- rep(0,n_sim)

D_q1_acc_40_59 <- rep(0,n_sim)
D_m_acc_40_59 <- rep(0,n_sim)
D_q2_acc_40_59 <- rep(0,n_sim)

D_q1_acc_60_79 <- rep(0,n_sim)
D_m_acc_60_79 <- rep(0,n_sim)
D_q2_acc_60_79 <- rep(0,n_sim)

D_q1_acc_over80 <- rep(0,n_sim)
D_m_acc_over80 <- rep(0,n_sim)
D_q2_acc_over80 <- rep(0,n_sim)

for (t in 1:n_sim){
  S_q_0_19 <- as.numeric(quantile(S_traj_0_19[t,], c(.025 , .5 , .975)))
  S_q_20_39 <- as.numeric(quantile(S_traj_20_39[t,], c(.025, .5 , .975)))
  S_q_40_59 <- as.numeric(quantile(S_traj_40_59[t,], c(.025, .5 , .975)))
  S_q_60_79 <- as.numeric(quantile(S_traj_60_79[t,], c(.025, .5 , .975)))
  S_q_over80 <- as.numeric(quantile(S_traj_over80[t,], c(.025, .5 , .975)))
  
  S_q1_0_19[t] <- S_q_0_19[1]
  S_m_0_19[t] <- S_q_0_19[2]
  S_q2_0_19[t] <- S_q_0_19[3]
  
  S_q1_20_39[t] <- S_q_20_39[1]
  S_m_20_39[t] <- S_q_20_39[2]
  S_q2_20_39[t] <- S_q_20_39[3]
  
  S_q1_40_59[t] <- S_q_40_59[1]
  S_m_40_59[t] <- S_q_40_59[2]
  S_q2_40_59[t] <- S_q_40_59[3]
  
  S_q1_60_79[t] <- S_q_60_79[1]
  S_m_60_79[t] <- S_q_60_79[2]
  S_q2_60_79[t] <- S_q_60_79[3]
  
  S_q1_over80[t] <- S_q_over80[1]
  S_m_over80[t] <- S_q_over80[2]
  S_q2_over80[t] <- S_q_over80[3]
  
  E_q_0_19 <- as.numeric(quantile(E_traj_0_19[t,], c(.025 , .5 , .975)))
  E_q_20_39 <- as.numeric(quantile(E_traj_20_39[t,], c(.025, .5 , .975)))
  E_q_40_59 <- as.numeric(quantile(E_traj_40_59[t,], c(.025, .5 , .975)))
  E_q_60_79 <- as.numeric(quantile(E_traj_60_79[t,], c(.025, .5 , .975)))
  E_q_over80 <- as.numeric(quantile(E_traj_over80[t,], c(.025, .5 , .975)))
  
  E_q1_0_19[t] <- E_q_0_19[1]
  E_m_0_19[t] <- E_q_0_19[2]
  E_q2_0_19[t] <- E_q_0_19[3]
  
  E_q1_20_39[t] <- E_q_20_39[1]
  E_m_20_39[t] <- E_q_20_39[2]
  E_q2_20_39[t] <- E_q_20_39[3]
  
  E_q1_40_59[t] <- E_q_40_59[1]
  E_m_40_59[t] <- E_q_40_59[2]
  E_q2_40_59[t] <- E_q_40_59[3]
  
  E_q1_60_79[t] <- E_q_60_79[1]
  E_m_60_79[t] <- E_q_60_79[2]
  E_q2_60_79[t] <- E_q_60_79[3]
  
  E_q1_over80[t] <- E_q_over80[1]
  E_m_over80[t] <- E_q_over80[2]
  E_q2_over80[t] <- E_q_over80[3]
  
  
  P_q_0_19 <- as.numeric(quantile(P_traj_0_19[t,], c(.025 , .5 , .975)))
  P_q_20_39 <- as.numeric(quantile(P_traj_20_39[t,], c(.025, .5 , .975)))
  P_q_40_59 <- as.numeric(quantile(P_traj_40_59[t,], c(.025, .5 , .975)))
  P_q_60_79 <- as.numeric(quantile(P_traj_60_79[t,], c(.025, .5 , .975)))
  P_q_over80 <- as.numeric(quantile(P_traj_over80[t,], c(.025, .5 , .975)))
  
  P_q1_0_19[t] <- P_q_0_19[1]
  P_m_0_19[t] <- P_q_0_19[2]
  P_q2_0_19[t] <- P_q_0_19[3]
  
  P_q1_20_39[t] <- P_q_20_39[1]
  P_m_20_39[t] <- P_q_20_39[2]
  P_q2_20_39[t] <- P_q_20_39[3]
  
  P_q1_40_59[t] <- P_q_40_59[1]
  P_m_40_59[t] <- P_q_40_59[2]
  P_q2_40_59[t] <- P_q_40_59[3]
  
  P_q1_60_79[t] <- P_q_60_79[1]
  P_m_60_79[t] <- P_q_60_79[2]
  P_q2_60_79[t] <- P_q_60_79[3]
  
  P_q1_over80[t] <- P_q_over80[1]
  P_m_over80[t] <- P_q_over80[2]
  P_q2_over80[t] <- P_q_over80[3]
  
  IS_q_0_19 <- as.numeric(quantile(IS_traj_0_19[t,], c(.025 , .5 , .975)))
  IS_q_20_39 <- as.numeric(quantile(IS_traj_20_39[t,], c(.025, .5 , .975)))
  IS_q_40_59 <- as.numeric(quantile(IS_traj_40_59[t,], c(.025, .5 , .975)))
  IS_q_60_79 <- as.numeric(quantile(IS_traj_60_79[t,], c(.025, .5 , .975)))
  IS_q_over80 <- as.numeric(quantile(IS_traj_over80[t,], c(.025, .5 , .975)))
  
  IS_q1_0_19[t] <- IS_q_0_19[1]
  IS_m_0_19[t] <- IS_q_0_19[2]
  IS_q2_0_19[t] <- IS_q_0_19[3]
  
  IS_q1_20_39[t] <- IS_q_20_39[1]
  IS_m_20_39[t] <- IS_q_20_39[2]
  IS_q2_20_39[t] <- IS_q_20_39[3]
  
  IS_q1_40_59[t] <- IS_q_40_59[1]
  IS_m_40_59[t] <- IS_q_40_59[2]
  IS_q2_40_59[t] <- IS_q_40_59[3]
  
  IS_q1_60_79[t] <- IS_q_60_79[1]
  IS_m_60_79[t] <- IS_q_60_79[2]
  IS_q2_60_79[t] <- IS_q_60_79[3]
  
  IS_q1_over80[t] <- IS_q_over80[1]
  IS_m_over80[t] <- IS_q_over80[2]
  IS_q2_over80[t] <- IS_q_over80[3]
  
  IA_q_0_19 <- as.numeric(quantile(IA_traj_0_19[t,], c(.025 , .5 , .975)))
  IA_q_20_39 <- as.numeric(quantile(IA_traj_20_39[t,], c(.025, .5 , .975)))
  IA_q_40_59 <- as.numeric(quantile(IA_traj_40_59[t,], c(.025, .5 , .975)))
  IA_q_60_79 <- as.numeric(quantile(IA_traj_60_79[t,], c(.025, .5 , .975)))
  IA_q_over80 <- as.numeric(quantile(IA_traj_over80[t,], c(.025, .5 , .975)))
  
  IA_q1_0_19[t] <- IA_q_0_19[1]
  IA_m_0_19[t] <- IA_q_0_19[2]
  IA_q2_0_19[t] <- IA_q_0_19[3]
  
  IA_q1_20_39[t] <- IA_q_20_39[1]
  IA_m_20_39[t] <- IA_q_20_39[2]
  IA_q2_20_39[t] <- IA_q_20_39[3]
  
  IA_q1_40_59[t] <- IA_q_40_59[1]
  IA_m_40_59[t] <- IA_q_40_59[2]
  IA_q2_40_59[t] <- IA_q_40_59[3]
  
  IA_q1_60_79[t] <- IA_q_60_79[1]
  IA_m_60_79[t] <- IA_q_60_79[2]
  IA_q2_60_79[t] <- IA_q_60_79[3]
  
  IA_q1_over80[t] <- IA_q_over80[1]
  IA_m_over80[t] <- IA_q_over80[2]
  IA_q2_over80[t] <- IA_q_over80[3]
  
  H_q_0_19 <- as.numeric(quantile(H_traj_0_19[t,], c(.025 , .5 , .975)))
  H_q_20_39 <- as.numeric(quantile(H_traj_20_39[t,], c(.025, .5 , .975)))
  H_q_40_59 <- as.numeric(quantile(H_traj_40_59[t,], c(.025, .5 , .975)))
  H_q_60_79 <- as.numeric(quantile(H_traj_60_79[t,], c(.025, .5 , .975)))
  H_q_over80 <- as.numeric(quantile(H_traj_over80[t,], c(.025, .5 , .975)))
  
  H_q1_0_19[t] <- H_q_0_19[1]
  H_m_0_19[t] <- H_q_0_19[2]
  H_q2_0_19[t] <- H_q_0_19[3]
  
  H_q1_20_39[t] <- H_q_20_39[1]
  H_m_20_39[t] <- H_q_20_39[2]
  H_q2_20_39[t] <- H_q_20_39[3]
  
  H_q1_40_59[t] <- H_q_40_59[1]
  H_m_40_59[t] <- H_q_40_59[2]
  H_q2_40_59[t] <- H_q_40_59[3]
  
  H_q1_60_79[t] <- H_q_60_79[1]
  H_m_60_79[t] <- H_q_60_79[2]
  H_q2_60_79[t] <- H_q_60_79[3]
  
  H_q1_over80[t] <- H_q_over80[1]
  H_m_over80[t] <- H_q_over80[2]
  H_q2_over80[t] <- H_q_over80[3]
  
  IC_q_0_19 <- as.numeric(quantile(IC_traj_0_19[t,], c(.025 , .5 , .975)))
  IC_q_20_39 <- as.numeric(quantile(IC_traj_20_39[t,], c(.025, .5 , .975)))
  IC_q_40_59 <- as.numeric(quantile(IC_traj_40_59[t,], c(.025, .5 , .975)))
  IC_q_60_79 <- as.numeric(quantile(IC_traj_60_79[t,], c(.025, .5 , .975)))
  IC_q_over80 <- as.numeric(quantile(IC_traj_over80[t,], c(.025, .5 , .975)))
  
  IC_q1_0_19[t] <- IC_q_0_19[1]
  IC_m_0_19[t] <- IC_q_0_19[2]
  IC_q2_0_19[t] <- IC_q_0_19[3]
  
  IC_q1_20_39[t] <- IC_q_20_39[1]
  IC_m_20_39[t] <- IC_q_20_39[2]
  IC_q2_20_39[t] <- IC_q_20_39[3]
  
  IC_q1_40_59[t] <- IC_q_40_59[1]
  IC_m_40_59[t] <- IC_q_40_59[2]
  IC_q2_40_59[t] <- IC_q_40_59[3]
  
  IC_q1_60_79[t] <- IC_q_60_79[1]
  IC_m_60_79[t] <- IC_q_60_79[2]
  IC_q2_60_79[t] <- IC_q_60_79[3]
  
  IC_q1_over80[t] <- IC_q_over80[1]
  IC_m_over80[t] <- IC_q_over80[2]
  IC_q2_over80[t] <- IC_q_over80[3]
  
  IS_q_inc_0_19 <- as.numeric(quantile(IS_inc_traj_0_19[t,], c(.025 , .5 , .975)))
  IS_q_inc_20_39 <- as.numeric(quantile(IS_inc_traj_20_39[t,], c(.025, .5 , .975)))
  IS_q_inc_40_59 <- as.numeric(quantile(IS_inc_traj_40_59[t,], c(.025, .5 , .975)))
  IS_q_inc_60_79 <- as.numeric(quantile(IS_inc_traj_60_79[t,], c(.025, .5 , .975)))
  IS_q_inc_over80 <- as.numeric(quantile(IS_inc_traj_over80[t,], c(.025, .5 , .975)))
  
  IS_q1_inc_0_19[t] <- IS_q_inc_0_19[1]
  IS_m_inc_0_19[t] <- IS_q_inc_0_19[2]
  IS_q2_inc_0_19[t] <- IS_q_inc_0_19[3]
  
  IS_q1_inc_20_39[t] <- IS_q_inc_20_39[1]
  IS_m_inc_20_39[t] <- IS_q_inc_20_39[2]
  IS_q2_inc_20_39[t] <- IS_q_inc_20_39[3]
  
  IS_q1_inc_40_59[t] <- IS_q_inc_40_59[1]
  IS_m_inc_40_59[t] <- IS_q_inc_40_59[2]
  IS_q2_inc_40_59[t] <- IS_q_inc_40_59[3]
  
  IS_q1_inc_60_79[t] <- IS_q_inc_60_79[1]
  IS_m_inc_60_79[t] <- IS_q_inc_60_79[2]
  IS_q2_inc_60_79[t] <- IS_q_inc_60_79[3]
  
  IS_q1_inc_over80[t] <- IS_q_inc_over80[1]
  IS_m_inc_over80[t] <- IS_q_inc_over80[2]
  IS_q2_inc_over80[t] <- IS_q_inc_over80[3]  
  
  H_q_inc_0_19 <- as.numeric(quantile(H_inc_traj_0_19[t,], c(.025 , .5 , .975)))
  H_q_inc_20_39 <- as.numeric(quantile(H_inc_traj_20_39[t,], c(.025, .5 , .975)))
  H_q_inc_40_59 <- as.numeric(quantile(H_inc_traj_40_59[t,], c(.025, .5 , .975)))
  H_q_inc_60_79 <- as.numeric(quantile(H_inc_traj_60_79[t,], c(.025, .5 , .975)))
  H_q_inc_over80 <- as.numeric(quantile(H_inc_traj_over80[t,], c(.025, .5 , .975)))
  
  H_q1_inc_0_19[t] <- H_q_inc_0_19[1]
  H_m_inc_0_19[t] <- H_q_inc_0_19[2]
  H_q2_inc_0_19[t] <- H_q_inc_0_19[3]
  
  H_q1_inc_20_39[t] <- H_q_inc_20_39[1]
  H_m_inc_20_39[t] <- H_q_inc_20_39[2]
  H_q2_inc_20_39[t] <- H_q_inc_20_39[3]
  
  H_q1_inc_40_59[t] <- H_q_inc_40_59[1]
  H_m_inc_40_59[t] <- H_q_inc_40_59[2]
  H_q2_inc_40_59[t] <- H_q_inc_40_59[3]
  
  H_q1_inc_60_79[t] <- H_q_inc_60_79[1]
  H_m_inc_60_79[t] <- H_q_inc_60_79[2]
  H_q2_inc_60_79[t] <- H_q_inc_60_79[3]
  
  H_q1_inc_over80[t] <- H_q_inc_over80[1]
  H_m_inc_over80[t] <- H_q_inc_over80[2]
  H_q2_inc_over80[t] <- H_q_inc_over80[3]
  
  IC_q_inc_0_19 <- as.numeric(quantile(IC_inc_traj_0_19[t,], c(.025 , .5 , .975)))
  IC_q_inc_20_39 <- as.numeric(quantile(IC_inc_traj_20_39[t,], c(.025, .5 , .975)))
  IC_q_inc_40_59 <- as.numeric(quantile(IC_inc_traj_40_59[t,], c(.025, .5 , .975)))
  IC_q_inc_60_79 <- as.numeric(quantile(IC_inc_traj_60_79[t,], c(.025, .5 , .975)))
  IC_q_inc_over80 <- as.numeric(quantile(IC_inc_traj_over80[t,], c(.025, .5 , .975)))
  
  IC_q1_inc_0_19[t] <- IC_q_inc_0_19[1]
  IC_m_inc_0_19[t] <- IC_q_inc_0_19[2]
  IC_q2_inc_0_19[t] <- IC_q_inc_0_19[3]
  
  IC_q1_inc_20_39[t] <- IC_q_inc_20_39[1]
  IC_m_inc_20_39[t] <- IC_q_inc_20_39[2]
  IC_q2_inc_20_39[t] <- IC_q_inc_20_39[3]
  
  IC_q1_inc_40_59[t] <- IC_q_inc_40_59[1]
  IC_m_inc_40_59[t] <- IC_q_inc_40_59[2]
  IC_q2_inc_40_59[t] <- IC_q_inc_40_59[3]
  
  IC_q1_inc_60_79[t] <- IC_q_inc_60_79[1]
  IC_m_inc_60_79[t] <- IC_q_inc_60_79[2]
  IC_q2_inc_60_79[t] <- IC_q_inc_60_79[3]
  
  IC_q1_inc_over80[t] <- IC_q_inc_over80[1]
  IC_m_inc_over80[t] <- IC_q_inc_over80[2]
  IC_q2_inc_over80[t] <- IC_q_inc_over80[3]
  
  D_q_inc_0_19 <- as.numeric(quantile(D_inc_traj_0_19[t,], c(.025 , .5 , .975)))
  D_q_inc_20_39 <- as.numeric(quantile(D_inc_traj_20_39[t,], c(.025, .5 , .975)))
  D_q_inc_40_59 <- as.numeric(quantile(D_inc_traj_40_59[t,], c(.025, .5 , .975)))
  D_q_inc_60_79 <- as.numeric(quantile(D_inc_traj_60_79[t,], c(.025, .5 , .975)))
  D_q_inc_over80 <- as.numeric(quantile(D_inc_traj_over80[t,], c(.025, .5 , .975)))
  
  D_q1_inc_0_19[t] <- D_q_inc_0_19[1]
  D_m_inc_0_19[t] <- D_q_inc_0_19[2]
  D_q2_inc_0_19[t] <- D_q_inc_0_19[3]
  
  D_q1_inc_20_39[t] <- D_q_inc_20_39[1]
  D_m_inc_20_39[t] <- D_q_inc_20_39[2]
  D_q2_inc_20_39[t] <- D_q_inc_20_39[3]
  
  D_q1_inc_40_59[t] <- D_q_inc_40_59[1]
  D_m_inc_40_59[t] <- D_q_inc_40_59[2]
  D_q2_inc_40_59[t] <- D_q_inc_40_59[3]
  
  D_q1_inc_60_79[t] <- D_q_inc_60_79[1]
  D_m_inc_60_79[t] <- D_q_inc_60_79[2]
  D_q2_inc_60_79[t] <- D_q_inc_60_79[3]
  
  D_q1_inc_over80[t] <- D_q_inc_over80[1]
  D_m_inc_over80[t] <- D_q_inc_over80[2]
  D_q2_inc_over80[t] <- D_q_inc_over80[3]
  
  IS_q_acc_0_19 <- as.numeric(quantile(IS_acc_traj_0_19[t,], c(.025 , .5 , .975)))
  IS_q_acc_20_39 <- as.numeric(quantile(IS_acc_traj_20_39[t,], c(.025, .5 , .975)))
  IS_q_acc_40_59 <- as.numeric(quantile(IS_acc_traj_40_59[t,], c(.025, .5 , .975)))
  IS_q_acc_60_79 <- as.numeric(quantile(IS_acc_traj_60_79[t,], c(.025, .5 , .975)))
  IS_q_acc_over80 <- as.numeric(quantile(IS_acc_traj_over80[t,], c(.025, .5 , .975)))
  
  IS_q1_acc_0_19[t] <- IS_q_acc_0_19[1]
  IS_m_acc_0_19[t] <- IS_q_acc_0_19[2]
  IS_q2_acc_0_19[t] <- IS_q_acc_0_19[3]
  
  IS_q1_acc_20_39[t] <- IS_q_acc_20_39[1]
  IS_m_acc_20_39[t] <- IS_q_acc_20_39[2]
  IS_q2_acc_20_39[t] <- IS_q_acc_20_39[3]
  
  IS_q1_acc_40_59[t] <- IS_q_acc_40_59[1]
  IS_m_acc_40_59[t] <- IS_q_acc_40_59[2]
  IS_q2_acc_40_59[t] <- IS_q_acc_40_59[3]
  
  IS_q1_acc_60_79[t] <- IS_q_acc_60_79[1]
  IS_m_acc_60_79[t] <- IS_q_acc_60_79[2]
  IS_q2_acc_60_79[t] <- IS_q_acc_60_79[3]
  
  IS_q1_acc_over80[t] <- IS_q_acc_over80[1]
  IS_m_acc_over80[t] <- IS_q_acc_over80[2]
  IS_q2_acc_over80[t] <- IS_q_acc_over80[3]  
  
  H_q_acc_0_19 <- as.numeric(quantile(H_acc_traj_0_19[t,], c(.025 , .5 , .975)))
  H_q_acc_20_39 <- as.numeric(quantile(H_acc_traj_20_39[t,], c(.025, .5 , .975)))
  H_q_acc_40_59 <- as.numeric(quantile(H_acc_traj_40_59[t,], c(.025, .5 , .975)))
  H_q_acc_60_79 <- as.numeric(quantile(H_acc_traj_60_79[t,], c(.025, .5 , .975)))
  H_q_acc_over80 <- as.numeric(quantile(H_acc_traj_over80[t,], c(.025, .5 , .975)))
  
  H_q1_acc_0_19[t] <- H_q_acc_0_19[1]
  H_m_acc_0_19[t] <- H_q_acc_0_19[2]
  H_q2_acc_0_19[t] <- H_q_acc_0_19[3]
  
  H_q1_acc_20_39[t] <- H_q_acc_20_39[1]
  H_m_acc_20_39[t] <- H_q_acc_20_39[2]
  H_q2_acc_20_39[t] <- H_q_acc_20_39[3]
  
  H_q1_acc_40_59[t] <- H_q_acc_40_59[1]
  H_m_acc_40_59[t] <- H_q_acc_40_59[2]
  H_q2_acc_40_59[t] <- H_q_acc_40_59[3]
  
  H_q1_acc_60_79[t] <- H_q_acc_60_79[1]
  H_m_acc_60_79[t] <- H_q_acc_60_79[2]
  H_q2_acc_60_79[t] <- H_q_acc_60_79[3]
  
  H_q1_acc_over80[t] <- H_q_acc_over80[1]
  H_m_acc_over80[t] <- H_q_acc_over80[2]
  H_q2_acc_over80[t] <- H_q_acc_over80[3]
  
  IC_q_acc_0_19 <- as.numeric(quantile(IC_acc_traj_0_19[t,], c(.025 , .5 , .975)))
  IC_q_acc_20_39 <- as.numeric(quantile(IC_acc_traj_20_39[t,], c(.025, .5 , .975)))
  IC_q_acc_40_59 <- as.numeric(quantile(IC_acc_traj_40_59[t,], c(.025, .5 , .975)))
  IC_q_acc_60_79 <- as.numeric(quantile(IC_acc_traj_60_79[t,], c(.025, .5 , .975)))
  IC_q_acc_over80 <- as.numeric(quantile(IC_acc_traj_over80[t,], c(.025, .5 , .975)))
  
  IC_q1_acc_0_19[t] <- IC_q_acc_0_19[1]
  IC_m_acc_0_19[t] <- IC_q_acc_0_19[2]
  IC_q2_acc_0_19[t] <- IC_q_acc_0_19[3]
  
  IC_q1_acc_20_39[t] <- IC_q_acc_20_39[1]
  IC_m_acc_20_39[t] <- IC_q_acc_20_39[2]
  IC_q2_acc_20_39[t] <- IC_q_acc_20_39[3]
  
  IC_q1_acc_40_59[t] <- IC_q_acc_40_59[1]
  IC_m_acc_40_59[t] <- IC_q_acc_40_59[2]
  IC_q2_acc_40_59[t] <- IC_q_acc_40_59[3]
  
  IC_q1_acc_60_79[t] <- IC_q_acc_60_79[1]
  IC_m_acc_60_79[t] <- IC_q_acc_60_79[2]
  IC_q2_acc_60_79[t] <- IC_q_acc_60_79[3]
  
  IC_q1_acc_over80[t] <- IC_q_acc_over80[1]
  IC_m_acc_over80[t] <- IC_q_acc_over80[2]
  IC_q2_acc_over80[t] <- IC_q_acc_over80[3]
  
  D_q_acc_0_19 <- as.numeric(quantile(D_acc_traj_0_19[t,], c(.025 , .5 , .975)))
  D_q_acc_20_39 <- as.numeric(quantile(D_acc_traj_20_39[t,], c(.025, .5 , .975)))
  D_q_acc_40_59 <- as.numeric(quantile(D_acc_traj_40_59[t,], c(.025, .5 , .975)))
  D_q_acc_60_79 <- as.numeric(quantile(D_acc_traj_60_79[t,], c(.025, .5 , .975)))
  D_q_acc_over80 <- as.numeric(quantile(D_acc_traj_over80[t,], c(.025, .5 , .975)))
  
  D_q1_acc_0_19[t] <- D_q_acc_0_19[1]
  D_m_acc_0_19[t] <- D_q_acc_0_19[2]
  D_q2_acc_0_19[t] <- D_q_acc_0_19[3]
  
  D_q1_acc_20_39[t] <- D_q_acc_20_39[1]
  D_m_acc_20_39[t] <- D_q_acc_20_39[2]
  D_q2_acc_20_39[t] <- D_q_acc_20_39[3]
  
  D_q1_acc_40_59[t] <- D_q_acc_40_59[1]
  D_m_acc_40_59[t] <- D_q_acc_40_59[2]
  D_q2_acc_40_59[t] <- D_q_acc_40_59[3]
  
  D_q1_acc_60_79[t] <- D_q_acc_60_79[1]
  D_m_acc_60_79[t] <- D_q_acc_60_79[2]
  D_q2_acc_60_79[t] <- D_q_acc_60_79[3]
  
  D_q1_acc_over80[t] <- D_q_acc_over80[1]
  D_m_acc_over80[t] <- D_q_acc_over80[2]
  D_q2_acc_over80[t] <- D_q_acc_over80[3]
  
}

# Plots --------------------------------------------------------------

#fit <- readRDS('fit.rds')

#pars=c('beta', 's', 'l','nu',
#       'omega_0_19','omega_20_39','omega_40_59','omega_60_79','omega_over80',
#       'gamma_D_0_19','gamma_D_20_39','gamma_D_40_59','gamma_D_60_79','gamma_D_over80',
#       'alpha_0_19','alpha_20_39','alpha_40_59','alpha_60_79','alpha_over80',
#       'psi_0_19','psi_20_39','psi_40_59','psi_60_79','psi_over80',
#       'rho_0_19','rho_20_39','rho_40_59','rho_60_79','rho_over80',
#       'iA0','d')

#standen <- stan_dens(fit, pars = pars, separate_chains = TRUE)

dir_output  <- file.path("Figures")
dir.create(dir_output,  recursive = TRUE, showWarnings = FALSE)

titles <- c("Posteriors", "R0", 
            "Susceptibles", "Exposed", "Presymptomatics", "Symptomatics", "Asymptomatics", "Hospitalized", "Intensive_Care",
            "Acc_Symptomatics", "Acc_Hospitalized", "Acc_Intensive_Care", "Acc_Deaths",
            "Inc_Symptomatics", "Inc_Hospitalized", "Inc_Intensive_Care", "Inc_Deaths",
            "Inc_Symptomatics_0-19","Inc_Symptomatics_20-39","Inc_Symptomatics_40-59","Inc_Symptomatics_60-79","Inc_Symptomatics_over80",
            "Inc_Hospitalized_0-19","Inc_Hospitalized_20-39","Inc_Hospitalized_40-59","Inc_Hospitalized_60-79","Inc_Hospitalized_over80",
            "Inc_Intensive_Care_0-19","Inc_Intensive_Care_20-39","Inc_Intensive_Care_40-59","Inc_Intensive_Care_60-79","Inc_Intensive_Care_over80",
            "Inc_Deaths_0-19","Inc_Deaths_20-39","Inc_Deaths_40-59","Inc_Deaths_60-79","Inc_Deaths_over80")

k <- 1

#png(paste(titles[k],".png"))

#plot(standen)

#dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(density(R0_eff_vec, adjust=1.75), lty="dotted",col = "black", pch = 10,main = "R0")

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 50), ylim = c(650000, 3100000),main = "Susceptibles")
lines(1:n_sim, S_m_0_19, col = "cornflowerblue", lwd = 2)
lines(1:n_sim, S_m_20_39, col = "darkorchid1", lwd = 2)
lines(1:n_sim, S_m_40_59, col = "firebrick1", lwd = 2)
lines(1:n_sim, S_m_60_79, col = "green", lwd = 2)
lines(1:n_sim, S_m_over80, col = "grey", lwd = 2)
lines(1:n_sim, S_q1_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, S_q1_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, S_q1_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, S_q1_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, S_q1_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, S_q2_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, S_q2_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, S_q2_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, S_q2_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, S_q2_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 150), ylim = c(0, 60000),main = "Exposed")
lines(1:n_sim, E_m_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, E_m_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, E_m_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, E_m_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, E_m_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, E_q1_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, E_q1_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, E_q1_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, E_q1_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, E_q1_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, E_q2_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, E_q2_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, E_q2_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, E_q2_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, E_q2_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 150), ylim = c(0, 25000),main = "Presymptomatics")
lines(1:n_sim, P_m_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, P_m_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, P_m_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, P_m_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, P_m_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, P_q1_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, P_q1_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, P_q1_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, P_q1_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, P_q1_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, P_q2_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, P_q2_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, P_q2_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, P_q2_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, P_q2_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 150), ylim = c(0, 12500),main = "Symptomatics")
lines(1:n_sim, IS_m_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, IS_m_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, IS_m_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, IS_m_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, IS_m_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, IS_q1_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q1_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q1_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q1_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q1_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 150), ylim = c(0, 22500),main = "Asymptomatics")
lines(1:n_sim, IA_m_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, IA_m_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, IA_m_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, IA_m_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, IA_m_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, IA_q1_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IA_q1_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IA_q1_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IA_q1_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IA_q1_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IA_q2_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IA_q2_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IA_q2_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IA_q2_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IA_q2_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 150), ylim = c(0, 7000),main = "Hospitalized")
lines(1:n_sim, H_m_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, H_m_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, H_m_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, H_m_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, H_m_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, H_q1_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 150), ylim = c(0, 350),main = "Intensive Care")
lines(1:n_sim, IC_m_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, IC_m_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, IC_m_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, IC_m_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, IC_m_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, IC_q1_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 150), ylim = c(0, 35000),main = "Acc. Symptomatics")
lines(1:n_sim, IS_m_acc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, IS_m_acc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, IS_m_acc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, IS_m_acc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, IS_m_acc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, IS_q1_acc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q1_acc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q1_acc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q1_acc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q1_acc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_acc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_acc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_acc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_acc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_acc_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 150), ylim = c(0, 30000),main = "Acc. Hospitalized")
lines(1:n_sim, H_m_acc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, H_m_acc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, H_m_acc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, H_m_acc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, H_m_acc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, H_q1_acc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_acc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_acc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_acc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_acc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_acc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_acc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_acc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_acc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_acc_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 200), ylim = c(0, 4000),main = "Acc. Intensive Care")
lines(1:n_sim, IC_m_acc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, IC_m_acc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, IC_m_acc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, IC_m_acc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, IC_m_acc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, IC_q1_acc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_acc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_acc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_acc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_acc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_acc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_acc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_acc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_acc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_acc_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 200), ylim = c(0, 12000),main = "Acc. Deaths")
lines(1:n_sim, D_m_acc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, D_m_acc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, D_m_acc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, D_m_acc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, D_m_acc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, D_q1_acc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q1_acc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q1_acc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q1_acc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q1_acc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_acc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_acc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_acc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_acc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_acc_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0, 1200),main = "Inc. Symptomatics")
points(x = IS_dataset$time_sequence, y = IS_dataset$Group1, pch = 20, col = "cornflowerblue",ylim = c(0, 750))
points(x = IS_dataset$time_sequence, y = IS_dataset$Group2, pch = 20, col = "darkorchid1")
points(x = IS_dataset$time_sequence, y = IS_dataset$Group3, pch = 20, col = "firebrick1")
points(x = IS_dataset$time_sequence, y = IS_dataset$Group4, pch = 20, col = "green")
points(x = IS_dataset$time_sequence, y = IS_dataset$Group5, pch = 20, col = "grey")
lines(1:n_sim, IS_q1_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_m_inc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, IS_q1_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_m_inc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, IS_q1_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_m_inc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, IS_q1_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_m_inc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, IS_q1_inc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_m_inc_over80, col = "grey", lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0, 1000),main = "Inc. Hospitalized")
points(x = H_dataset$time_sequence, y = H_dataset$Group1, pch = 20, col = "cornflowerblue",ylim = c(0, 750))
points(x = H_dataset$time_sequence, y = H_dataset$Group2, pch = 20, col = "darkorchid1")
points(x = H_dataset$time_sequence, y = H_dataset$Group3, pch = 20, col = "firebrick1")
points(x = H_dataset$time_sequence, y = H_dataset$Group4, pch = 20, col = "green")
points(x = H_dataset$time_sequence, y = H_dataset$Group5, pch = 20, col = "grey")
lines(1:n_sim, H_m_inc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, H_m_inc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, H_m_inc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, H_m_inc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, H_m_inc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, H_q1_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q1_inc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,100), main = "Inc. Intensive Care")
points(x = IC_dataset$time_sequence, y = IC_dataset$Group1, pch = 20, col = "cornflowerblue",ylim = c(0, 150))
points(x = IC_dataset$time_sequence, y = IC_dataset$Group2, pch = 20, col = "darkorchid1")
points(x = IC_dataset$time_sequence, y = IC_dataset$Group3, pch = 20, col = "firebrick1")
points(x = IC_dataset$time_sequence, y = IC_dataset$Group4, pch = 20, col = "green")
points(x = IC_dataset$time_sequence, y = IC_dataset$Group5, pch = 20, col = "grey")
lines(1:n_sim, IC_m_inc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, IC_m_inc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, IC_m_inc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, IC_m_inc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, IC_m_inc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, IC_q1_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q1_inc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,300), main = "Inc. Deaths")
points(x = D_dataset$time_sequence, y = D_dataset$Group1, pch = 20, col = "cornflowerblue")
points(x = D_dataset$time_sequence, y = D_dataset$Group2, pch = 20, col = "darkorchid1")
points(x = D_dataset$time_sequence, y = D_dataset$Group3, pch = 20, col = "firebrick1")
points(x = D_dataset$time_sequence, y = D_dataset$Group4, pch = 20, col = "green")
points(x = D_dataset$time_sequence, y = D_dataset$Group5, pch = 20, col = "grey")
lines(1:n_sim, D_m_inc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, D_m_inc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, D_m_inc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, D_m_inc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, D_m_inc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, D_q1_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q1_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q1_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q1_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q1_inc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_over80, col = "grey", lty = 5, lwd = 1.5)
legend("topright",inset=0.02, legend=c("0-19", "20-39","40-59","60-79","over80"),
       col=c("cornflowerblue","darkorchid1","firebrick1","green", "grey"), lty=1 ,cex=1,
       text.font=4, bg='white',lwd = 2)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,50), main = "Inc. Symptomatics 0-19")
points(x = IS_dataset$time_sequence, y = IS_dataset$Group1, pch = 20, col = "cornflowerblue")
lines(1:n_sim, IS_m_inc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, IS_q1_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,250), main = "Inc. Symptomatics 20-39")
points(x = IS_dataset$time_sequence, y = IS_dataset$Group2, pch = 20, col = "darkorchid1")
lines(1:n_sim, IS_m_inc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, IS_q1_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,1000), main = "Inc. Symptomatics 40-59")
points(x = IS_dataset$time_sequence, y = IS_dataset$Group3, pch = 20, col = "firebrick1")
lines(1:n_sim, IS_m_inc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, IS_q1_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,1200), main = "Inc. Symptomatics 60-79")
points(x = IS_dataset$time_sequence, y = IS_dataset$Group4, pch = 20, col = "green")
lines(1:n_sim, IS_m_inc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, IS_q1_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_60_79, col = "green", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,600), main = "Inc. Symptomatics over80")
points(x = IS_dataset$time_sequence, y = IS_dataset$Group5, pch = 20, col = "grey")
lines(1:n_sim, IS_m_inc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, IS_q1_inc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IS_q2_inc_over80, col = "grey", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,10), main = "Inc. Hospitalized 0-19")
points(x = H_dataset$time_sequence, y = H_dataset$Group1, pch = 20, col = "cornflowerblue")
lines(1:n_sim, H_m_inc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, H_q1_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,90), main = "Inc. Hospitalized 20-39")
points(x = H_dataset$time_sequence, y = H_dataset$Group2, pch = 20, col = "darkorchid1")
lines(1:n_sim, H_m_inc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, H_q1_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,700), main = "Inc. Hospitalized 40-59")
points(x = H_dataset$time_sequence, y = H_dataset$Group3, pch = 20, col = "firebrick1")
lines(1:n_sim, H_m_inc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, H_q1_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,1000), main = "Inc. Hospitalized 60-79")
points(x = H_dataset$time_sequence, y = H_dataset$Group4, pch = 20, col = "green")
lines(1:n_sim, H_m_inc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, H_q1_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_60_79, col = "green", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,400), main = "Inc. Hospitalized over80")
points(x = H_dataset$time_sequence, y = H_dataset$Group5, pch = 20, col = "grey")
lines(1:n_sim, H_m_inc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, H_q1_inc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, H_q2_inc_over80, col = "grey", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,0.25), main = "Inc. Int. Care 0-19")
points(x = IC_dataset$time_sequence, y = IC_dataset$Group1, pch = 20, col = "cornflowerblue")
lines(1:n_sim, IC_m_inc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, IC_q1_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,5), main = "Inc. Int. Care 20-39")
points(x = IC_dataset$time_sequence, y = IC_dataset$Group2, pch = 20, col = "darkorchid1")
lines(1:n_sim, IC_m_inc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, IC_q1_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,70), main = "Inc. Int. Care 40-59")
points(x = IC_dataset$time_sequence, y = IC_dataset$Group3, pch = 20, col = "firebrick1")
lines(1:n_sim, IC_m_inc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, IC_q1_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,100), main = "Inc. Int. Care 60-79")
points(x = IC_dataset$time_sequence, y = IC_dataset$Group4, pch = 20, col = "green")
lines(1:n_sim, IC_m_inc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, IC_q1_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_60_79, col = "green", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,1.5), main = "Inc. Int. Care over80")
points(x = IC_dataset$time_sequence, y = IC_dataset$Group5, pch = 20, col = "grey")
lines(1:n_sim, IC_m_inc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, IC_q1_inc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, IC_q2_inc_over80, col = "grey", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,0.25), main = "Inc. Deaths 0-19")
points(x = D_dataset$time_sequence, y = D_dataset$Group1, pch = 20, col = "cornflowerblue")
lines(1:n_sim, D_m_inc_0_19, col = "cornflowerblue", lwd = 1.5)
lines(1:n_sim, D_q1_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_0_19, col = "cornflowerblue", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,5), main = "Inc. Deaths 20-39")
points(x = D_dataset$time_sequence, y = D_dataset$Group2, pch = 20, col = "darkorchid1")
lines(1:n_sim, D_m_inc_20_39, col = "darkorchid1", lwd = 1.5)
lines(1:n_sim, D_q1_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_20_39, col = "darkorchid1", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,70), main = "Inc. Deaths 40-59")
points(x = D_dataset$time_sequence, y = D_dataset$Group3, pch = 20, col = "firebrick1")
lines(1:n_sim, D_m_inc_40_59, col = "firebrick1", lwd = 1.5)
lines(1:n_sim, D_q1_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_40_59, col = "firebrick1", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,280), main = "Inc. Deaths 60-79")
points(x = D_dataset$time_sequence, y = D_dataset$Group4, pch = 20, col = "green")
lines(1:n_sim, D_m_inc_60_79, col = "green", lwd = 1.5)
lines(1:n_sim, D_q1_inc_60_79, col = "green", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_60_79, col = "green", lty = 5, lwd = 1.5)

dev.off()
k <- k + 1
png(paste(titles[k],".png"))

plot(1, type="n", xlab="Time", ylab="", xlim=c(0, 120), ylim = c(0,220), main = "Inc. Deaths over80")
points(x = D_dataset$time_sequence, y = D_dataset$Group5, pch = 20, col = "grey")
lines(1:n_sim, D_m_inc_over80, col = "grey", lwd = 1.5)
lines(1:n_sim, D_q1_inc_over80, col = "grey", lty = 5, lwd = 1.5)
lines(1:n_sim, D_q2_inc_over80, col = "grey", lty = 5, lwd = 1.5)

dev.off()